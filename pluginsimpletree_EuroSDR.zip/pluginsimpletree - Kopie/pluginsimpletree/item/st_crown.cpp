#include "st_crown.h"


CT_DEFAULT_IA_INIT(ST_Crown)

ST_Crown::ST_Crown() : CT_AbstractItemDrawableWithoutPointCloud()
{
}

ST_Crown::ST_Crown(const CT_OutAbstractSingularItemModel *model,
                 const CT_AbstractResult *result,
                 QSharedPointer<Crown> crown) : CT_AbstractItemDrawableWithoutPointCloud(model, result)
{
    _crown = crown;
}

ST_Crown::ST_Crown(const QString &modelName,
                 const CT_AbstractResult *result,
                 QSharedPointer<Crown> crown) : CT_AbstractItemDrawableWithoutPointCloud(modelName, result)
{
   _crown = crown;
}


CT_AbstractItemDrawable* ST_Crown::copy(const CT_OutAbstractItemModel *model, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Crown *ref = new ST_Crown((const CT_OutAbstractSingularItemModel *)model, result, _crown);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());

    return ref;
}

CT_AbstractItemDrawable *ST_Crown::copy(const QString &modelName, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Crown *ref = new ST_Crown(modelName, result, _crown);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());
    return ref;
}

QString ST_Crown::getCrownID() const
{
    return _id.completeName();
}


