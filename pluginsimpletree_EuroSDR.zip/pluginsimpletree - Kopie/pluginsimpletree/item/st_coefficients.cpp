
#include "item/st_coefficients.h"

CT_DEFAULT_IA_INIT(ST_Coefficients)

ST_Coefficients::ST_Coefficients() : CT_AbstractItemDrawableWithoutPointCloud()
{
}

ST_Coefficients::ST_Coefficients(const CT_OutAbstractSingularItemModel *model,
                 const CT_AbstractResult *result, MethodCoefficients coeff) : CT_AbstractItemDrawableWithoutPointCloud(model, result)
{
    _coeff = coeff;
}

//QString ST_Coefficients::staticGetType()
//{
//    return "ST_Coefficients";

//}



ST_Coefficients::ST_Coefficients(const QString &modelName,
                 const CT_AbstractResult *result, MethodCoefficients coeff) : CT_AbstractItemDrawableWithoutPointCloud(modelName, result)
{
    _coeff = coeff;
}

CT_AbstractItemDrawable* ST_Coefficients::copy(const CT_OutAbstractItemModel *model, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Coefficients *ref = new ST_Coefficients((const CT_OutAbstractSingularItemModel *)model, result, _coeff);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());
    return ref;
}

CT_AbstractItemDrawable *ST_Coefficients::copy(const QString &modelName, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Coefficients *ref = new ST_Coefficients(modelName, result,_coeff);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());
    return ref;
}

QString ST_Coefficients::getcoeffID() const
{
    return _id.completeName();
}

