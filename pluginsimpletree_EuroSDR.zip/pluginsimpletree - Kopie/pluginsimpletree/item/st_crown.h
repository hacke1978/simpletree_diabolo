#ifndef ST_CROWN_H
#define ST_CROWN_H

#include "SimpleTree4/model/crown.h"


#include "ct_itemdrawable/abstract/ct_abstractitemdrawablewithoutpointcloud.h"
#include "ct_itemdrawable/tools/drawmanager/ct_standardreferencepointdrawmanager.h"
#include "SimpleTree4/method/method_coefficients.h"
#include "ct_tools/model/ct_autorenamemodels.h"

#include <QSharedPointer>


class ST_Crown : public CT_AbstractItemDrawableWithoutPointCloud
{
    Q_OBJECT
    CT_TYPE_IMPL_MACRO(ST_Crown, CT_AbstractItemDrawableWithoutPointCloud, CrownModel)

    public:
        ST_Crown();

    /**
      * \brief Contructeur
      */
    ST_Crown(const CT_OutAbstractSingularItemModel *model,
             const CT_AbstractResult *result,
             QSharedPointer<Crown> crown);

    ST_Crown(const QString &modelName,
             const CT_AbstractResult *result,
             QSharedPointer<Crown> crown);

    virtual CT_AbstractItemDrawable* copy(const CT_OutAbstractItemModel *model, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList);

    virtual CT_AbstractItemDrawable* copy(const QString &modelName, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList);

    QSharedPointer<Crown> get_crown() const {return _crown;}

    QString getCrownID() const;


private:

    CT_AutoRenameModels _id;

    QSharedPointer<Crown>   _crown;


    CT_DEFAULT_IA_BEGIN(ST_Crown)
    CT_DEFAULT_IA_V3(ST_Crown, CT_AbstractCategory::staticInitDataId(),  &ST_Crown::getCrownID, QObject::tr("ID"), "id")
    CT_DEFAULT_IA_V3(ST_Crown, CT_AbstractCategory::staticInitDataId(),  &ST_Crown::getCrownID, QObject::tr("ID"), "id")
    CT_DEFAULT_IA_END(ST_Crown)

};


#endif // ST_CROWN_H
