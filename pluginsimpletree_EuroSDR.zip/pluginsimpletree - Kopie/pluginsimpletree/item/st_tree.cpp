
#include "item/st_tree.h"

CT_DEFAULT_IA_INIT(ST_Tree)

ST_Tree::ST_Tree() : CT_AbstractItemDrawableWithoutPointCloud()
{
}

ST_Tree::ST_Tree(const CT_OutAbstractSingularItemModel *model,
                 const CT_AbstractResult *result,
                 QSharedPointer<Tree> tree) : CT_AbstractItemDrawableWithoutPointCloud(model, result)
{
    _tree = tree;
}

ST_Tree::ST_Tree(const QString &modelName,
                 const CT_AbstractResult *result,
                 QSharedPointer<Tree> tree) : CT_AbstractItemDrawableWithoutPointCloud(modelName, result)
{
    _tree = tree;
}

//QString ST_Tree::staticGetType()
//{
//    return "ST_Tree";

//}

CT_AbstractItemDrawable* ST_Tree::copy(const CT_OutAbstractItemModel *model, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Tree *ref = new ST_Tree((const CT_OutAbstractSingularItemModel *)model, result, _tree);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());

    return ref;
}

CT_AbstractItemDrawable *ST_Tree::copy(const QString &modelName, const CT_AbstractResult *result, CT_ResultCopyModeList copyModeList)
{
    ST_Tree *ref = new ST_Tree(modelName, result, _tree);
    ref->setAlternativeDrawManager(getAlternativeDrawManager());
    return ref;
}

QString ST_Tree::getTreeID() const
{
    return _id.completeName();
}


