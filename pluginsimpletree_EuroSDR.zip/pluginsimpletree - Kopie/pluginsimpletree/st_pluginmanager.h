#ifndef ST_PLUGINMANAGER_H
#define ST_PLUGINMANAGER_H

#include "ct_abstractstepplugin.h"

#include "ct_log/ct_fileloglistener.h"

class ST_PluginManager : public CT_AbstractStepPlugin
{
public:
    ST_PluginManager();
    ~ST_PluginManager();

    QString getPluginURL() const {return QString("http://rdinnovation.onf.fr/projects/PLUGINS-PROJECT-NAME-HERE/wiki");}

protected:

    bool loadGenericsStep();
    bool loadOpenFileStep();
    bool loadCanBeAddedFirstStep();
    bool loadActions();
    bool loadExporters();
    bool loadReaders();

private:
    CT_FileLogListener  m_logListener;
};

#endif // ST_PLUGINMANAGER_H
