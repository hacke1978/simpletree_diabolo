#include "st_pluginentry.h"
#include "st_pluginmanager.h"

ST_PluginEntry::ST_PluginEntry()
{
    _pluginManager = new ST_PluginManager();
}

ST_PluginEntry::~ST_PluginEntry()
{
    delete _pluginManager;
}

QString ST_PluginEntry::getVersion() const
{
    return "1.0";
}

CT_AbstractStepPlugin* ST_PluginEntry::getPlugin() const
{
    return _pluginManager;
}

#if QT_VERSION < QT_VERSION_CHECK(5, 0, 0)
    Q_EXPORT_PLUGIN2(plug_simpletree, ST_PluginEntry)
#endif
