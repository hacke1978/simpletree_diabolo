/********************************************************************************
** Form generated from reading UI file 'st_actionstempointdetectionoptions.ui'
**
** Created by: Qt User Interface Compiler version 5.9.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H
#define UI_ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ST_ActionStemPointDetectionOptions
{
public:
    QHBoxLayout *horizontalLayout;
    QWidget *wd_toolbar;
    QVBoxLayout *verticalLayout;
    QWidget *widget;
    QHBoxLayout *horizontalLayout_2;
    QDoubleSpinBox *eigen_1_min;
    QDoubleSpinBox *eigen_1_max;
    QDoubleSpinBox *eigen_2_min;
    QDoubleSpinBox *eigen_2_max;
    QDoubleSpinBox *eigen_3_min;
    QDoubleSpinBox *eigen_3_max;

    void setupUi(QWidget *ST_ActionStemPointDetectionOptions)
    {
        if (ST_ActionStemPointDetectionOptions->objectName().isEmpty())
            ST_ActionStemPointDetectionOptions->setObjectName(QStringLiteral("ST_ActionStemPointDetectionOptions"));
        ST_ActionStemPointDetectionOptions->resize(709, 50);
        ST_ActionStemPointDetectionOptions->setLocale(QLocale(QLocale::English, QLocale::UnitedStates));
        horizontalLayout = new QHBoxLayout(ST_ActionStemPointDetectionOptions);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        wd_toolbar = new QWidget(ST_ActionStemPointDetectionOptions);
        wd_toolbar->setObjectName(QStringLiteral("wd_toolbar"));
        verticalLayout = new QVBoxLayout(wd_toolbar);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(wd_toolbar);
        widget->setObjectName(QStringLiteral("widget"));
        horizontalLayout_2 = new QHBoxLayout(widget);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        eigen_1_min = new QDoubleSpinBox(widget);
        eigen_1_min->setObjectName(QStringLiteral("eigen_1_min"));
        eigen_1_min->setDecimals(3);
        eigen_1_min->setMaximum(100);

        horizontalLayout_2->addWidget(eigen_1_min);

        eigen_1_max = new QDoubleSpinBox(widget);
        eigen_1_max->setObjectName(QStringLiteral("eigen_1_max"));
        eigen_1_max->setDecimals(3);
        eigen_1_max->setMaximum(100);
        eigen_1_max->setValue(100);

        horizontalLayout_2->addWidget(eigen_1_max);

        eigen_2_min = new QDoubleSpinBox(widget);
        eigen_2_min->setObjectName(QStringLiteral("eigen_2_min"));
        eigen_2_min->setDecimals(3);
        eigen_2_min->setMaximum(100);

        horizontalLayout_2->addWidget(eigen_2_min);

        eigen_2_max = new QDoubleSpinBox(widget);
        eigen_2_max->setObjectName(QStringLiteral("eigen_2_max"));
        eigen_2_max->setDecimals(3);
        eigen_2_max->setMaximum(100);
        eigen_2_max->setValue(100);

        horizontalLayout_2->addWidget(eigen_2_max);

        eigen_3_min = new QDoubleSpinBox(widget);
        eigen_3_min->setObjectName(QStringLiteral("eigen_3_min"));
        eigen_3_min->setDecimals(3);
        eigen_3_min->setMaximum(100);

        horizontalLayout_2->addWidget(eigen_3_min);

        eigen_3_max = new QDoubleSpinBox(widget);
        eigen_3_max->setObjectName(QStringLiteral("eigen_3_max"));
        eigen_3_max->setDecimals(3);
        eigen_3_max->setMaximum(100);
        eigen_3_max->setValue(100);

        horizontalLayout_2->addWidget(eigen_3_max);


        verticalLayout->addWidget(widget);


        horizontalLayout->addWidget(wd_toolbar);


        retranslateUi(ST_ActionStemPointDetectionOptions);

        QMetaObject::connectSlotsByName(ST_ActionStemPointDetectionOptions);
    } // setupUi

    void retranslateUi(QWidget *ST_ActionStemPointDetectionOptions)
    {
        ST_ActionStemPointDetectionOptions->setWindowTitle(QApplication::translate("ST_ActionStemPointDetectionOptions", "Form", Q_NULLPTR));
#ifndef QT_NO_TOOLTIP
        ST_ActionStemPointDetectionOptions->setToolTip(QString());
#endif // QT_NO_TOOLTIP
    } // retranslateUi

};

namespace Ui {
    class ST_ActionStemPointDetectionOptions: public Ui_ST_ActionStemPointDetectionOptions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H
