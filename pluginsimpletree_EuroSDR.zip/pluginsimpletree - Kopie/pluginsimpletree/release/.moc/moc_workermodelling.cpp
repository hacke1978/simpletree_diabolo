/****************************************************************************
** Meta object code from reading C++ file 'workermodelling.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../step/modelling/workermodelling.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'workermodelling.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_WorkerModelling_t {
    QByteArrayData data[6];
    char stringdata0[82];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_WorkerModelling_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_WorkerModelling_t qt_meta_stringdata_WorkerModelling = {
    {
QT_MOC_LITERAL(0, 0, 15), // "WorkerModelling"
QT_MOC_LITERAL(1, 16, 20), // "emit_finished_worker"
QT_MOC_LITERAL(2, 37, 0), // ""
QT_MOC_LITERAL(3, 38, 19), // "emit_qstring_worker"
QT_MOC_LITERAL(4, 58, 3), // "str"
QT_MOC_LITERAL(5, 62, 19) // "sent_qstring_worker"

    },
    "WorkerModelling\0emit_finished_worker\0"
    "\0emit_qstring_worker\0str\0sent_qstring_worker"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_WorkerModelling[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       3,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   29,    2, 0x06 /* Public */,
       3,    1,   30,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   33,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    4,

       0        // eod
};

void WorkerModelling::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        WorkerModelling *_t = static_cast<WorkerModelling *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->emit_finished_worker(); break;
        case 1: _t->emit_qstring_worker((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: _t->sent_qstring_worker((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (WorkerModelling::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&WorkerModelling::emit_finished_worker)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (WorkerModelling::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&WorkerModelling::emit_qstring_worker)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject WorkerModelling::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_WorkerModelling.data,
      qt_meta_data_WorkerModelling,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *WorkerModelling::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *WorkerModelling::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_WorkerModelling.stringdata0))
        return static_cast<void*>(const_cast< WorkerModelling*>(this));
    if (!strcmp(_clname, "QRunnable"))
        return static_cast< QRunnable*>(const_cast< WorkerModelling*>(this));
    return QObject::qt_metacast(_clname);
}

int WorkerModelling::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 3)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void WorkerModelling::emit_finished_worker()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void WorkerModelling::emit_qstring_worker(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
