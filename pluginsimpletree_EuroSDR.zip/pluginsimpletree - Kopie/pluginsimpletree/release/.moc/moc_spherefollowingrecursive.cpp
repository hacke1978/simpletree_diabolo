/****************************************************************************
** Meta object code from reading C++ file 'spherefollowingrecursive.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SimpleTree4/method/spherefollowingrecursive.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'spherefollowingrecursive.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SphereFollowingRecursive_t {
    QByteArrayData data[9];
    char stringdata0[161];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SphereFollowingRecursive_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SphereFollowingRecursive_t qt_meta_stringdata_SphereFollowingRecursive = {
    {
QT_MOC_LITERAL(0, 0, 24), // "SphereFollowingRecursive"
QT_MOC_LITERAL(1, 25, 37), // "emit_qstring_spherefollowingr..."
QT_MOC_LITERAL(2, 63, 0), // ""
QT_MOC_LITERAL(3, 64, 4), // "qstr"
QT_MOC_LITERAL(4, 69, 37), // "emit_counter_spherefollowingr..."
QT_MOC_LITERAL(5, 107, 7), // "counter"
QT_MOC_LITERAL(6, 115, 13), // "emit_finished"
QT_MOC_LITERAL(7, 129, 15), // "receive_qstring"
QT_MOC_LITERAL(8, 145, 15) // "receive_counter"

    },
    "SphereFollowingRecursive\0"
    "emit_qstring_spherefollowingrecursive\0"
    "\0qstr\0emit_counter_spherefollowingrecursive\0"
    "counter\0emit_finished\0receive_qstring\0"
    "receive_counter"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SphereFollowingRecursive[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,
       4,    1,   42,    2, 0x06 /* Public */,
       6,    0,   45,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       7,    1,   46,    2, 0x0a /* Public */,
       8,    1,   49,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::Int,    5,

       0        // eod
};

void SphereFollowingRecursive::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SphereFollowingRecursive *_t = static_cast<SphereFollowingRecursive *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->emit_qstring_spherefollowingrecursive((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 1: _t->emit_counter_spherefollowingrecursive((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->emit_finished(); break;
        case 3: _t->receive_qstring((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->receive_counter((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SphereFollowingRecursive::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SphereFollowingRecursive::emit_qstring_spherefollowingrecursive)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (SphereFollowingRecursive::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SphereFollowingRecursive::emit_counter_spherefollowingrecursive)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (SphereFollowingRecursive::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SphereFollowingRecursive::emit_finished)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject SphereFollowingRecursive::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_SphereFollowingRecursive.data,
      qt_meta_data_SphereFollowingRecursive,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *SphereFollowingRecursive::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SphereFollowingRecursive::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SphereFollowingRecursive.stringdata0))
        return static_cast<void*>(const_cast< SphereFollowingRecursive*>(this));
    return QObject::qt_metacast(_clname);
}

int SphereFollowingRecursive::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void SphereFollowingRecursive::emit_qstring_spherefollowingrecursive(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SphereFollowingRecursive::emit_counter_spherefollowingrecursive(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SphereFollowingRecursive::emit_finished()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
