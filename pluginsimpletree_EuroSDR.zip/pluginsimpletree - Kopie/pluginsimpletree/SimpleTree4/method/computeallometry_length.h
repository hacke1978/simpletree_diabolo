#ifndef COMPUTEALLOMETRY_LENGTH_H
#define COMPUTEALLOMETRY_LENGTH_H

#include <SimpleTree4/model/tree.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include "ct_math/ct_mathfittedline2d.h"
#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/QR>



class ComputeAllometryLength
{
    QSharedPointer<Tree> _tree;


    float _a_length;
    float _b_length;


    Eigen::MatrixXd generate_Jacobian(QVector<float>& rad);

    Eigen::MatrixXd generate_value_matrix(QVector<float>& rad, QVector<float>& vol);

    void gauss_newton(QVector<float>& rad, QVector<float>& vol);

    void compute();

    void compute_min_rad_vol();

    void generate_vectors(QVector<float> &rad, QVector<float> &vol, QVector<float> &rad_2, QVector<float> &vol_2);


public:
    ComputeAllometryLength(QSharedPointer<Tree> tree);
    float get_a() const;
    void set_a(float a);
    float get_b() const;
    void set_b(float b);
};

#endif // COMPUTEALLOMETRY_LENGTH_H
