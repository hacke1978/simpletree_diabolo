#ifndef OPTIMIZATIONGAP_H
#define OPTIMIZATIONGAP_H

#include <QThreadPool>
#include <QMutexLocker>
#include <QMutex>
#include <QEnableSharedFromThis>
#include <QVector>

#include <SimpleTree4/model/pointsimpletree.h>
#include <SimpleTree4/method/method_coefficients.h>
#include <SimpleTree4/method/workerspherefollowing.h>
#include <SimpleTree4/math/simplemath.h>
#include <SimpleTree4/model/build_tree/buildtree.h>

class OptimizationGap
{
    PointCloudS::Ptr _cloud;
    MethodCoefficients _coeff;
    QSharedPointer<Tree> _tree;
    bool _subdivide_stem_and_branch_points;

    QVector<QSharedPointer<Segment> > extract_segments(QSharedPointer<Tree> tree);

    float segment_area(QSharedPointer<Segment> segment);

    float sum_children_area(QSharedPointer<Segment> segment);

    bool check_pype(QVector<QSharedPointer<Segment> > segments);

public:
    OptimizationGap(PointCloudS::Ptr cloud, MethodCoefficients coeff, bool subdivide_stem_and_branch_points);

    void optimize();

    MethodCoefficients get_coeff() const;
};

#endif // OPTIMIZATIONGAP_H
