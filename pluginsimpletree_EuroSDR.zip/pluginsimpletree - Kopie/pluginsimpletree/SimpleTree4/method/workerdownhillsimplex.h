#ifndef WORKERDOWNHILLSIMPLEX_H
#define WORKERDOWNHILLSIMPLEX_H

#include <QRunnable>
#include <QSharedPointer>
#include <QVector>
#include "SimpleTree4/method/spherefollowing2.h"
#include "SimpleTree4/method/optimizationdownhillsimplex.h"
#include "SimpleTree4/method/computedistancecylinderscloud.h"

class OptimizationDownHillSimplex;

class WorkerDownhillSimplex: public QRunnable
{
    MethodCoefficients _coeff;
     PointCloudS::Ptr _cloud;
     QSharedPointer<OptimizationDownHillSimplex>  _optim;
     bool _subdivide_stem_and_branch_points;
     int _i;
     bool _is_dual;
public:
    WorkerDownhillSimplex(MethodCoefficients coeff, PointCloudS::Ptr cloud,
                          QSharedPointer<OptimizationDownHillSimplex> optim, bool subdivide_stem_and_branch_points, int i, bool is_dual =  false);

    void run();
};

#endif // WORKERDOWNHILLSIMPLEX_H
