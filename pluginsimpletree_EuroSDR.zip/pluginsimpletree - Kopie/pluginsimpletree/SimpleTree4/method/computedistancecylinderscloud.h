#ifndef COMPUTEDISTANCECYLINDERSCLOUD_H
#define COMPUTEDISTANCECYLINDERSCLOUD_H
#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/model/cylinder.h"
#include "SimpleTree4/math/simplemath.h"
#include "SimpleTree4/model/tree.h"


#include <pcl/octree/octree.h>
#include <pcl/octree/octree_impl.h>

#include <QVector>
#include <QSharedPointer>
#include <QtGlobal>

class ComputeDistanceCylindersCloud
{

    const float _MIN_DIST_TO_CYLINDER = 0.03f;

    const float _CYLINDER_SIZE_MULTIPLIER = 1.1f;

    PointCloudS::Ptr _cloud;

    QVector<QSharedPointer<Cylinder> > _cylinders;

    QSharedPointer<Cylinder> _cylinder;

    QVector<double> _distances_double;

    QVector<float> _distances_float;

    QVector<double> _distances_double_sqrd;

    QVector<float> _distances_float_sqrd;

    QVector<double> _distances_double_sqrd_normal;






    void
    compute_distances();

    void compute_distances_double_sqrd_with_power();

    float _distance = 0;

    float _distance_sqrd = 0;

    float _distance_sqrd_normal = 0;

    float _standard_deviation = 0;

    float _standard_deviation_sqrd = 0;


    /**
     * @brief extract_points_near_cylinder Returns a point cloud with the points near the cylinder
     * @param cylinder the input cylinder
     * @return the cloud
     */
    std::vector<int> extract_points_near_cylinder(QSharedPointer<Cylinder> cylinder,  QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > octree);
public:
    ComputeDistanceCylindersCloud(QVector<pcl::ModelCoefficients> cylinder_coeff, PointCloudS::Ptr cloud);

    ComputeDistanceCylindersCloud(QSharedPointer<Tree> tree, PointCloudS::Ptr cloud);

   // ComputeDistanceCylindersCloud(QVector<pcl::ModelCoefficients> cylinder_coeff, PointCloudS::Ptr cloud, float power  );


   ComputeDistanceCylindersCloud(QSharedPointer<Cylinder> cylinder, PointCloudS::Ptr cloud);


    QVector<double> get_distances_double() const;

    QVector<double> get_distances_double_sqrd() const;

    QVector<float> get_distances_float() const;

    QVector<float> get_distances_float_sqrd() const;

    float get_mean_sqrd_dist() const;

    float get_mean_dist() const;

    float get_sd_sqrd_dist() const;

    float get_sd_dist() const;

    float get_mean_sqrd_dist_normal() const;
};

#endif // COMPUTEDISTANCECYLINDERSCLOUD_H
