#ifndef WORKERFIT_H
#define WORKERFIT_H


#include <QRunnable>
#include <QSharedPointer>
#include <QVector>
#include "SimpleTree4/model/tree.h"
#include "SimpleTree4/method/optimizationfit.h"
#include "SimpleTree4/model/build_tree/improvefit.h"

#include "SimpleTree4/model/build_tree/buildtree.h"
#include "SimpleTree4/model/build_tree/improvebranchjunctions.h"
#include "SimpleTree4/model/build_tree/improvebymedian.h"
#include "SimpleTree4/model/build_tree/improvefit.h"
#include "SimpleTree4/model/build_tree/removefalsecylinders.h"
#include "SimpleTree4/model/build_tree/reordertree.h"
#include "SimpleTree4/model/build_tree/improvebymerge.h"
#include "SimpleTree4/method/optimizationspherefollowing.h"
#include "SimpleTree4/method/spherefollowingrecursive.h"
#include "SimpleTree4/model/build_tree/improvebyallometry.h"
#include "SimpleTree4/model/build_tree/improvebypipemodel.h"
#include "SimpleTree4/method/point_cloud_operations/computemeanandstandarddeviation.h"
#include "SimpleTree4/model/build_tree/improvedbyadvancedmedian.h"
#include "SimpleTree4/method/computeallometry.h"




class OptimizationFit;
class WorkerFit: public QRunnable
{
    QSharedPointer<OptimizationFit> _optim;
    MethodCoefficients _coeff;
    PointCloudS::Ptr _cloud;
    QVector<pcl::ModelCoefficients> _cylinder_coeff;

public:
    WorkerFit(MethodCoefficients coeff, PointCloudS::Ptr cloud, QSharedPointer<OptimizationFit> optim, QVector<pcl::ModelCoefficients> cylinder_coeff);

    void
    run();
};

#endif // WORKERFIT_H
