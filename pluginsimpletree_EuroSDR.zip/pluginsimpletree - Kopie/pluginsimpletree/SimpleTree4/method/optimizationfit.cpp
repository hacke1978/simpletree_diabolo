#include "optimizationfit.h"

QVector<MethodCoefficients> OptimizationFit::generate_coefficients()
{
    QVector<MethodCoefficients> coefficients;
    MethodCoefficients coeff_a = _coeff;
    for(int i = 0; i < 4; i++)
    {
        MethodCoefficients coeff_b = coeff_a;


        switch (i) {
        case 0:
        {
            coeff_b.number_of_merges = 0;
            break;
        }
        case 1:
        {
            coeff_b.number_of_merges = 1;
            break;
        }
        case 2:
        {
            coeff_b.number_of_merges = 2;
            break;
        }
        case 3:
        {
            coeff_b.number_of_merges = 3;
            break;
        }

        default:
            qDebug() << "critical error in optimization fit";
            break;
        }

        for(int j = 0; j < 5; j++)
        {
            MethodCoefficients coeff_c = coeff_b;
            switch (j) {
            case 0:
                coeff_c.ransac_inlier_distance = 0.01;
                break;
            case 1:
                coeff_c.ransac_inlier_distance = 0.02;
                break;
            case 2:
                coeff_c.ransac_inlier_distance = 0.03;
                break;
            case 3:
                coeff_c.ransac_inlier_distance = 0.04;
                break;
            case 4:
                coeff_c.ransac_inlier_distance = 0.05;
                break;
            default:
                qDebug() << "critical error in optimization fit";
                break;
            }
            coefficients.push_back(coeff_c);

        }
    }
    return coefficients;

}

OptimizationFit::OptimizationFit(PointCloudS::Ptr cloud, MethodCoefficients coeff,  QVector<pcl::ModelCoefficients> cylinder_coef, bool is_multithreaded)
{
    _cylinder_coeff = cylinder_coef;
    _cloud = cloud;
    _coeff = coeff;
    _coeff_end = coeff;
    _is_multithreaded = is_multithreaded;
}

void OptimizationFit::update_coeff(MethodCoefficients coeff, float distance, QSharedPointer<Tree> tree)
{
    if(_best_distance > distance)
    {
        _best_distance = distance;
        _coeff_end = coeff;
        _tree = tree;
    }
}

void OptimizationFit::optimize()
{
    _best_distance = 100;
    QVector<MethodCoefficients> coeff = generate_coefficients();
    QVectorIterator<MethodCoefficients> it (coeff);
    BuildTree builder(_cylinder_coeff);
    QSharedPointer<Tree> tree (new Tree(builder.getRoot_segment(), _coeff_end.id));
    RemoveFalseCylinders remove(tree);
    ImproveByMedian improve_by_median(tree);




    while(it.hasNext())
    {
        MethodCoefficients coefficients = it.next();


        int i = 0;
        while(i < coefficients.number_of_merges )
        {
                ImproveByMerge improve_merge(tree);
                i++;
        }
        AllocatePoints alloc (tree, _cloud);
        alloc.compute();
        QVector<PointCloudS::Ptr> clouds = alloc.get_sub_clouds();
        QVector<pcl::ModelCoefficients> coeffs = alloc.get_cylinder_coeff();
        QVector<QSharedPointer<Cylinder> > cylinders = tree->get_all_cylinders();

        for(size_t i = 0; i < clouds.size(); i++)
        {
            PointCloudS::Ptr sub_cloud = clouds.at(i);
            QSharedPointer<Cylinder> cylinder = cylinders.at(i);
            CylinderFit::general_cylinder_fit(sub_cloud,cylinder,
                                              coefficients.minPts_ransac_branch,coefficients.ransac_type,
                                              coefficients.ransac_inlier_distance,coefficients.ransac_iterations);
        }

        QVector<QSharedPointer<Cylinder> > cylinders_tree = tree->get_all_cylinders();
        QVector<pcl::ModelCoefficients> cylinder_coefficients;
        QVectorIterator<QSharedPointer<Cylinder> > git(cylinders_tree);

        while(git.hasNext())
        {
            QSharedPointer<Cylinder> cylinder = git.next();
            pcl::ModelCoefficients coefficients;
            coefficients.values = cylinder->values;
            cylinder_coefficients.push_back(coefficients);
        }

        ComputeDistanceCylindersCloud cd (cylinder_coefficients,_cloud);
        float dist = cd.get_mean_sqrd_dist_normal();
        update_coeff(coefficients, dist,tree);

        for(size_t i = 0; i < clouds.size(); i++)
        {
            pcl::ModelCoefficients original_coefficients = coeffs.at(i);
            QSharedPointer<Cylinder> cylinder = cylinders.at(i);
            cylinder->set_coeff(original_coefficients);
        }
    }
}
