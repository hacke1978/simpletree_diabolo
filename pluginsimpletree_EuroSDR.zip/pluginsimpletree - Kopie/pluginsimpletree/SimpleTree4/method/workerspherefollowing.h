#ifndef WORKERSPHEREFOLLOWING_H
#define WORKERSPHEREFOLLOWING_H

#include <QRunnable>
#include <QSharedPointer>
#include <QVector>
#include "SimpleTree4/method/spherefollowing2.h"
#include "SimpleTree4/method/optimizationspherefollowing.h"
#include "SimpleTree4/method/computedistancecylinderscloud.h"
class OptimizationSphereFollowing;

class WorkerSphereFollowing : public QRunnable
{
    QSharedPointer<OptimizationSphereFollowing> _optim;
    MethodCoefficients _coeff;
    PointCloudS::Ptr _cloud;
   bool _subdivide_stem_and_branch_points;

public:
    WorkerSphereFollowing(MethodCoefficients coeff, PointCloudS::Ptr cloud, QSharedPointer<OptimizationSphereFollowing> optim, bool subdivide_stem_and_branch_points);

    void
    run();
};

#endif // WORKERSPHEREFOLLOWING_H
