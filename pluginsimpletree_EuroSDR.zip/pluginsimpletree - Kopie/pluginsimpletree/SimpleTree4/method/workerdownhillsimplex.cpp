#include "workerdownhillsimplex.h"

WorkerDownhillSimplex::WorkerDownhillSimplex(MethodCoefficients coeff, PointCloudS::Ptr cloud,
                                             QSharedPointer<OptimizationDownHillSimplex> optim, bool subdivide_stem_and_branch_points, int i, bool is_dual)
{
    _coeff = coeff;
    _cloud = cloud;
    _optim = optim;
    _subdivide_stem_and_branch_points = subdivide_stem_and_branch_points;
    _i = i;
    _is_dual = is_dual;
}

void WorkerDownhillSimplex::run()
{
    SphereFollowing2 spherefollowing(_coeff,_cloud, _subdivide_stem_and_branch_points);
    spherefollowing.sphere_following();


    BuildTree builder(spherefollowing.get_cylinders());
    QSharedPointer<Tree> tree (new Tree(builder.getRoot_segment(),_coeff.id));
    RemoveFalseCylinders remove(tree);

    //QVector<pcl::ModelCoefficients> coeff_cylinder = spherefollowing.get_cylinders();
    ComputeDistanceCylindersCloud cd (tree,_cloud);
    float dist = cd.get_mean_sqrd_dist();;

    _optim->set_distance(_i,dist);


}
