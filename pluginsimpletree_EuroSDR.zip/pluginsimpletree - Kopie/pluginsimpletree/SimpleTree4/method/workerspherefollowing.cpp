#include "workerspherefollowing.h"

WorkerSphereFollowing::WorkerSphereFollowing(MethodCoefficients coeff, PointCloudS::Ptr cloud, QSharedPointer<OptimizationSphereFollowing> optim, bool subdivide_stem_and_branch_points)
{
    _cloud = cloud;
    _coeff = coeff;
    _optim = optim;
    _subdivide_stem_and_branch_points = subdivide_stem_and_branch_points;
}

void
WorkerSphereFollowing::run()
{
    SphereFollowing2 sf(_coeff, _cloud, _subdivide_stem_and_branch_points);
    sf.sphere_following();
    QVector<pcl::ModelCoefficients> coeff = sf.get_cylinders();
    ComputeDistanceCylindersCloud cd (coeff,_cloud);
    float dist = cd.get_mean_sqrd_dist();
    _optim->update_coeff(_coeff, dist);
}
