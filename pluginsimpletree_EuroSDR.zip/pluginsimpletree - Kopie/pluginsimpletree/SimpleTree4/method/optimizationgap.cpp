#include "optimizationgap.h"

OptimizationGap::OptimizationGap(PointCloudS::Ptr cloud, MethodCoefficients coeff, bool subdivide_stem_and_branch_points): _cloud(cloud), _coeff(coeff), _subdivide_stem_and_branch_points(subdivide_stem_and_branch_points)
{
    SphereFollowing2 spherefollowing(_coeff,_cloud, _subdivide_stem_and_branch_points);
    spherefollowing.sphere_following();

    BuildTree builder(spherefollowing.get_cylinders());
    QSharedPointer<Tree> tree (new Tree(builder.getRoot_segment(),_coeff.id));
    _tree = tree;
}

MethodCoefficients OptimizationGap::get_coeff() const
{
    return _coeff;
}

QVector<QSharedPointer<Segment> > OptimizationGap::extract_segments(QSharedPointer<Tree> tree)
{
    QVector<QSharedPointer<Segment> > all_segments = tree->get_all_segments();
    QVector<QSharedPointer<Segment> > result;
    QVectorIterator<QSharedPointer<Segment> > it(all_segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> seg = it.next();
        if(seg->get_mean_radius()>_coeff.min_radius_for_pype_test)
        {
            result.push_back(seg);
        }
    }
    return result;
}

float OptimizationGap::segment_area(QSharedPointer<Segment> segment)
{
    float radius = segment->get_mean_radius();
    float area = SimpleMath<float>::_PI*radius*radius;
    return area;
}

float OptimizationGap::sum_children_area(QSharedPointer<Segment> segment)
{
    QVector<QSharedPointer<Segment> > children = segment->get_child_segments();
    QVectorIterator<QSharedPointer<Segment> > it (children);
    float sum = 0;
    while(it.hasNext())
    {
        QSharedPointer<Segment> seg = it.next();
        sum += segment_area(seg);
    }
    return sum;
}

bool OptimizationGap::check_pype(QVector<QSharedPointer<Segment> > segments)
{
    int failure_segments = 0;
    QVectorIterator<QSharedPointer<Segment> > it(segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> seg = it.next();
        float area_parent = segment_area(seg);
        float area_children = sum_children_area(seg);
        if(area_children == 0)
        {
            failure_segments ++;
        }
        else
        {
            float ratio = area_parent/area_children;
            if(ratio<_coeff.min_ratio_pype||ratio>_coeff.max_ratio_pype)
            {
                failure_segments++;
            }
        }

    }
    if(failure_segments>_coeff.max_number_failure_segments)
    {
        return false;
    }
    return true;
}

void OptimizationGap::optimize()
{
    QVector<QSharedPointer<Segment> > segments = extract_segments(_tree);
    int number_iterations = 0;
    while(number_iterations<_coeff.max_times_cluster_extension && (!check_pype(segments)))
    {
        number_iterations ++;
        _coeff.epsilon_cluster_stem   = _coeff.epsilon_cluster_stem*2;
        _coeff.times_cluster_extension = number_iterations;
        SphereFollowing2 spherefollowing(_coeff,_cloud, _subdivide_stem_and_branch_points);
        spherefollowing.sphere_following();

        BuildTree builder(spherefollowing.get_cylinders());
        QSharedPointer<Tree> tree (new Tree(builder.getRoot_segment(),_coeff.id));
        _tree = tree;
        segments = extract_segments(_tree);
        qDebug() << "optimization gap doubled...";
    }
}
