#include "nlscylinderfit.h"

NLSCylinderFit::NLSCylinderFit(pcl::ModelCoefficients initial_coeff, PointCloudS::Ptr cloud)
{

}
