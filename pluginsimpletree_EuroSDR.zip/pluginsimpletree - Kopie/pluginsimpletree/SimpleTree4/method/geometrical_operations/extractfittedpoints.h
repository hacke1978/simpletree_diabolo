#ifndef EXTRACTFITTEDPOINTS_H
#define EXTRACTFITTEDPOINTS_H

#include <SimpleTree4/model/tree.h>
#include <SimpleTree4/method/computedistancecylinderscloud.h>

class ExtractFittedPoints
{

    PointCloudS::Ptr _cloud;
    PointCloudS::Ptr _cloud_out;

public:

    ExtractFittedPoints(PointCloudS::Ptr cloud, QVector<pcl::ModelCoefficients> coeff);


    PointCloudS::Ptr get_cloud_out() const;
};

#endif // EXTRACTFITTEDPOINTS_H
