#include "extractfittedpoints.h"

ExtractFittedPoints::ExtractFittedPoints(PointCloudS::Ptr cloud, QVector<pcl::ModelCoefficients> coeff)
{
    ComputeDistanceCylindersCloud cdc (coeff, cloud);
    QVector<float> distances = cdc.get_distances_float();
    float max_rad = 0;
    QVectorIterator<pcl::ModelCoefficients> it(coeff);
    while(it.hasNext())
    {
        pcl::ModelCoefficients cf = it.next();
        if(cf.values[6]>max_rad)
        {
            max_rad = cf.values[6];
        }

    }
    float min_dist = std::min(SimpleMath<float>::_UNFITTED_DISTANCE,max_rad);
    _cloud_out.reset(new PointCloudS);
    for(size_t i = 0; i < distances.size(); i++)
    {
        if(distances[i]>min_dist)
        {
            _cloud_out->points.push_back(cloud->points.at(i));
        }
    }

}

PointCloudS::Ptr ExtractFittedPoints::get_cloud_out() const
{
    return _cloud_out;
}


