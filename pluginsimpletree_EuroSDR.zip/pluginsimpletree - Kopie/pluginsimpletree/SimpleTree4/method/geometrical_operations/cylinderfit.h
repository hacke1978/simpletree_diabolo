#ifndef CYLINDERFIT_H
#define CYLINDERFIT_H


#include <SimpleTree4/model/pointsimpletree.h>
#include <SimpleTree4/model/cylinder.h>
#include <SimpleTree4/model/segment.h>
#include <SimpleTree4/math/simplemath.h>
#include <SimpleTree4/method/computedistancecylinderscloud.h>
#include <SimpleTree4/method/point_cloud_operations/computemeanandstandarddeviation.h>
#include <SimpleTree4/method/point_cloud_operations/voxelgridfilter.h>

#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/impl/sac_segmentation.hpp>


#include <QSharedPointer>

class CylinderFit
{
    const static float _MIN_RADIUS_MULTIPLIER;
    const static float _MAX_RADIUS_MULTIPLIER;
public:
    CylinderFit();

    const static pcl::ModelCoefficients get_cylinder_from_circles(pcl::ModelCoefficients circle1, pcl::ModelCoefficients circle2);

    const static pcl::ModelCoefficients ransac_cylinder_fit(PointCloudS::Ptr cloud, int type = SimpleMath<int>::_METHOD_TYPE , float distance = 0.03, int max_iterations = 100);

//     const static pcl::ModelCoefficients ransac_cylinder_fit(PointCloudS::Ptr cloud, int type = SimpleMath<int>::_METHOD_TYPE , float distance = 0.03, int max_iterations = 100,
  //                                                           const Eigen::Vector3f &ax = Eigen::Vector3f(), double rad = SimpleMath<float>::_PI);

    const static void median_cylinder_fit(QSharedPointer<Cylinder> cylinder, PointCloudS::Ptr cloud);


    const static void general_cylinder_fit(PointCloudS::Ptr cloud, QSharedPointer<Cylinder> cylinder, int minPTS, int type = SimpleMath<int>::_METHOD_TYPE
                                        , float distance = 0.03, int max_iterations = 100);

    const static void advanced_cylinder_fit(PointCloudS::Ptr cloud, QSharedPointer<Cylinder> cylinder, MethodCoefficients coeff);

};
#endif // CYLINDERFIT_H
