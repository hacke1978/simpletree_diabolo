#ifndef DETECTFALSECYLINDERS_H
#define DETECTFALSECYLINDERS_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/model/tree.h"




class DetectFalseCylinders
{
    PointCloudS::Ptr _cloud;

    PointCloudS::Ptr get_center_point_cloud(QSharedPointer<Tree> tree);

    void compute_distances_point_cylinder(PointS p, QSharedPointer<Cylinder> cylinder, float & distance, float & distance_sqrd, float & distance_sqrd_angle);

    QSharedPointer<Tree> _tree;

    void compute();

    float  _MAX_DIST = 0.12f;



public:
    DetectFalseCylinders(PointCloudS::Ptr cloud, QSharedPointer<Tree> tree);
};

#endif // DETECTFALSECYLINDERS_H
