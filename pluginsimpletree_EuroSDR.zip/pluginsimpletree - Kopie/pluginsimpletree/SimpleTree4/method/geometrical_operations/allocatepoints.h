#ifndef ALLOCATEPOINTS_H
#define ALLOCATEPOINTS_H

#include "SimpleTree4/model/tree.h"
#include "SimpleTree4/model/pointsimpletree.h"
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>


class AllocatePoints
{

    QVector<QSharedPointer<Cylinder> > _cylinders;

    QVector<pcl::ModelCoefficients> _cylinder_coeff;

    QVector<PointCloudS::Ptr> _sub_clouds;

    QSharedPointer<Tree> _tree;

    PointCloudS::Ptr _cloud;

    void initiate();

    void allocate();

    QSharedPointer<pcl::KdTreeFLANN<PointS> > _kdtree;

    bool only_sphere_following = true;




public:
    AllocatePoints(QSharedPointer<Tree> tree, PointCloudS::Ptr cloud);

    void compute();

    QVector<PointCloudS::Ptr> get_sub_clouds() const;

    QVector<pcl::ModelCoefficients> get_cylinder_coeff() const;
};

#endif // ALLOCATEPOINTS_H
