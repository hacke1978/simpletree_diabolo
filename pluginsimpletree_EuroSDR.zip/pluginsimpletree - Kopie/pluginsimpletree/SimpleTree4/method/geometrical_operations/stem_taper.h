#ifndef STEM_TAPER_H
#define STEM_TAPER_H

#include "SimpleTree4/model/tree.h"
#include "SimpleTree4/method/method_coefficients.h"
#include "SimpleTree4/model/build_tree/improvebypipemodel.h"
#include <ct_math/ct_mathfittedline2d.h>

class Stem_Taper
{
    MethodCoefficients _coeff;
    QSharedPointer<Tree> _tree;

    void compute();
public:
    static float get_DBH_from_taper(QSharedPointer<Tree> tree, MethodCoefficients cf);

    Stem_Taper(QSharedPointer<Tree> tree, MethodCoefficients coeff);
    MethodCoefficients coeff() const;
};

#endif // STEM_TAPER_H
