#include "allocatepoints.h"

QVector<PointCloudS::Ptr> AllocatePoints::get_sub_clouds() const
{
    return _sub_clouds;
}



QVector<pcl::ModelCoefficients> AllocatePoints::get_cylinder_coeff() const
{
    return _cylinder_coeff;
}

void AllocatePoints::initiate()
{
    /**
     * Sets the cylinder ID of each point to 0;
    **/
    for(size_t i = 0; i < _cloud->points.size(); i++)
    {
        _cloud->points[i].ID = -1;
    }

//    QVector<QSharedPointer<Cylinder> > all_cylinders = _tree->get_all_cylinders();
//    if(only_sphere_following)
//    {
//        _cylinders.clear();
//        QVectorIterator<QSharedPointer<Cylinder> > it (all_cylinders);
//        while(it.hasNext())
//        {
//            QSharedPointer<Cylinder> cylinder = it.next();
//            if(cylinder->get_detection() == DetectionType::SPHEREFOLLOWING)
//            {
//                _cylinders.push_back(cylinder);
//            }
//        }
//    } else
//    {
//        _cylinders = all_cylinders;
//    }

    _cylinders = _tree->get_all_cylinders();


    PointCloudS::Ptr center_points (new PointCloudS);
    _cylinder_coeff.clear();
    _sub_clouds.clear();
    QVectorIterator<QSharedPointer<Cylinder> > git (_cylinders);
    while(git.hasNext())
    {
        QSharedPointer<Cylinder> cylinder = git.next();
        center_points->points.push_back(cylinder->get_center());
        _cylinder_coeff.push_back(cylinder->get_coeff());
        PointCloudS::Ptr sub_cloud (new PointCloudS);
        _sub_clouds.push_back(sub_cloud);
    }

    _kdtree.reset(new pcl::KdTreeFLANN<PointS>);
    _kdtree->setInputCloud(center_points);
}

void AllocatePoints::allocate()
{
    MethodCoefficients cf;
    for(size_t i = 0; i < _cloud->points.size(); i++)
    {
        PointS p = _cloud->points.at(i);
        int K = 6;

        std::vector<int> pointIdxNKNSearch(K);
        std::vector<float> pointNKNSquaredDistance(K);
        _kdtree->nearestKSearch (p, K, pointIdxNKNSearch, pointNKNSquaredDistance);
        QSharedPointer<Cylinder> cylinder = _cylinders.at(pointIdxNKNSearch[0]);
        float distance = std::abs(cylinder->dist_to_point(p));
        int index = pointIdxNKNSearch[0];
        for(size_t j = 1; j < K; j++)
        {
            QSharedPointer<Cylinder> cylinder2 = _cylinders.at(pointIdxNKNSearch[j]);
            float distance2 = std::abs(cylinder2->dist_to_point(p));
            if(distance2 < distance)
            {
                distance = distance2;
                index = pointIdxNKNSearch[j];
            }
        }
        if(distance<cf.min_fitted_distance&&_cylinders[index]->get_detection()==DetectionType::SPHEREFOLLOWING)
        {
            _sub_clouds[index]->points.push_back(p);
        }
        _cloud->points[i].ID == index;
    }

}

AllocatePoints::AllocatePoints(QSharedPointer<Tree> tree, PointCloudS::Ptr cloud):_tree(tree), _cloud(cloud)
{
}

void AllocatePoints::compute()
{

    initiate();
    allocate();
}
