#ifndef NLSCYLINDERFIT_H
#define NLSCYLINDERFIT_H

#include <pcl/ModelCoefficients.h>
#include <SimpleTree4/model/pointsimpletree.h>
#include <SimpleTree4/model/cylinder.h>

#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/QR>

class NLSCylinderFit
{
    PointCloudS::Ptr _cloud;
    pcl::ModelCoefficients _updated_coeff;

    Eigen::MatrixXd generate_Jacobian(pcl::ModelCoefficients coeff);

    Eigen::MatrixXd
    generate_value_matrix(pcl::ModelCoefficients coeff);

public:
    NLSCylinderFit(pcl::ModelCoefficients initial_coeff, PointCloudS::Ptr cloud);
};

#endif // NLSCYLINDERFIT_H
