#ifndef SUBDIVIDESTEMANDBRANCHPOINTS_H
#define SUBDIVIDESTEMANDBRANCHPOINTS_H

#include "SimpleTree4/model/pointsimpletree.h"

class SubdivideStemAndBranchPoints
{
public:
    SubdivideStemAndBranchPoints();

    void static subdivide_points(PointCloudS::Ptr coud_in, PointCloudS::Ptr cloud_stem, PointCloudS::Ptr cloud_branch);
};

#endif // SUBDIVIDESTEMANDBRANCHPOINTS_H
