#include "convertcttost.h"

PointCloudS::Ptr ConvertCTtoST::get_cloud() const
{
    return _cloud;
}

ConvertCTtoST::ConvertCTtoST(CT_AbstractItemDrawableWithPointCloud *itemCpy_cloud_in, int knn, bool compute_curvature):
    _itemCpy_cloud_in(itemCpy_cloud_in), _knn(knn), _compute_curvature(compute_curvature)
{


}
PointCloudS::Ptr ConvertCTtoST::make_two_dimenstional()
{
    PointCloudS::Ptr result (new PointCloudS);
    size_t size = _cloud->points.size();
    result->points.resize(size);
    if(size > 0) {
        for(size_t i = 0; i < size; i++)
        {
            PointS p = _cloud->points.at(i);
            p.z = 0;

            result->points[i] = p;
        }
    }
    return result;
}

void ConvertCTtoST::convert()
{
    if (_itemCpy_cloud_in != NULL)
    {
        const CT_AbstractPointCloudIndex* index =_itemCpy_cloud_in->getPointCloudIndex();

        size_t size = index->size();

        _cloud.reset(new PointCloudS);
        _cloud->width = (int) size;
        _cloud->height = 1;



        if(size > 0) {
            _cloud->points.resize(size);
            size_t i = 0;
            CT_PointIterator it (index);
            while(it.hasNext())
            {


              const CT_Point &internalPoint = it.next().currentPoint();
                PointS p(internalPoint(0),internalPoint(1),internalPoint(2));
                _cloud->points[i] = p;
                ++i;
            }
        }
        if(_compute_curvature)
        {
            EnrichCloud enrich(_cloud, _knn, 0.03, true);
            StemPointDetection stempts (0,0.15,0.3,1,0,0.8,0.035,_cloud,1) ;
            stempts.compute();
        }
    } else {
        qDebug () << "foo";
    }
}
