#ifndef CONVERTCTTOST_H
#define CONVERTCTTOST_H

#include "ct_itemdrawable/abstract/ct_abstractitemdrawablewithpointcloud.h"
#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/method/point_cloud_operations/enrichcloud.h"
#include "SimpleTree4/method/point_cloud_operations/stempointdetection.h"
#include "ct_iterator/ct_pointiterator.h"
#include "QDebug"

class ConvertCTtoST
{
    CT_AbstractItemDrawableWithPointCloud* _itemCpy_cloud_in;

    PointCloudS::Ptr _cloud;
public:
    ConvertCTtoST(CT_AbstractItemDrawableWithPointCloud* itemCpy_cloud_in, int knn, bool compute_curvature = true);

    void convert();

    PointCloudS::Ptr make_two_dimenstional();

    PointCloudS::Ptr get_cloud() const;

private:

    int _knn;

    bool _compute_curvature = true;
};

#endif // CONVERTCTTOST_H
