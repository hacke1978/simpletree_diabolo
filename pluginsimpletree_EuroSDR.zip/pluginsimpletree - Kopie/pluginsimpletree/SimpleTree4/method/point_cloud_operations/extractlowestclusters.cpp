#include "extractlowestclusters.h"

QVector<PointCloudS::Ptr> ExtractLowestClusters::get_clusters() const
{
    return clusters;
}

ExtractLowestClusters::ExtractLowestClusters(PointCloudS::Ptr _cloud, float height, float thresh)
{
    float minZ;
    minZ = std::numeric_limits<float>::max();

    for(int i = 0; i< _cloud->points.size(); i++)
    {


        if(minZ > _cloud->points[i].z)
        {
            minZ = _cloud->points[i].z;
        }
    }

    PointCloudS::Ptr _lowest_cloud_1 (new PointCloudS);
    PointCloudS::Ptr _lowest_cloud_2 (new PointCloudS);
    pcl::PassThrough<PointS> pass_1;
    pass_1.setInputCloud(_cloud);
    pass_1.setFilterFieldName("z");
    pass_1.setFilterLimits(minZ, minZ+height);
    pass_1.filter(*_lowest_cloud_1);

//    pcl::PassThrough<PointS> pass_2;
//    pass_2.setInputCloud(_cloud);
//    pass_2.setFilterFieldName("z");
//    pass_2.setFilterLimits((minZ+ height, minZ+2*height));
//    pass_2.filter(_lowest_cloud_2);

//    if(_lowest_cloud_1->points.size()<)


    clusters = ClusterCloud::cluster(_lowest_cloud_1, thresh);

}
