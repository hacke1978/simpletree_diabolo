#ifndef ENRICHCLOUD_H
#define ENRICHCLOUD_H


#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/normal_3d_omp.h>

#include <QThread>
#include <QDebug>

#include "SimpleTree4/model/pointsimpletree.h"


class EnrichCloud
{
private:

    /**
     * @brief _cloud_in The cloud to be enriched with curvature information
     */
    PointCloudS::Ptr _cloud_in;

    /**
     * @brief _kdtree The KDtree used for the computation
     */
    pcl::KdTreeFLANN<PointS>::Ptr _kdtree;

    /**
     * @brief _k The K for knn search
     */
    int _k = 15;
    /**
     * @brief _range The radius for radius search
     */
    float _range = 0.03;
    /**
     * @brief _use_knn_search True if knn search is applied, false for radius search
     */
    bool _use_knn_search = true;

    /**
     * @brief compute All methods are wrapped here
     */
    void
    compute();

    /**
     * @brief compute_normals Compute the normals, multithreaded routine if possible
     */
    void
    compute_normals();

public:
    /**
     * @brief EnrichCloud Enriches a cloud with curvature information
     * @param cloud_in the input cloud
     * @param k the number of k nearest neighbors for knn search
     * @param range the range for range search
     * @param use_knn true if knn search is to be used, false for range search
     */
    EnrichCloud(PointCloudS::Ptr cloud_in, int k = 15, float range = 0.03f, bool use_knn = true );



};

#endif // ENRICHCLOUD_H
