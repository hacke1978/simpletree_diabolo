#include "enrichcloud.h"

void EnrichCloud::compute()
{
    compute_normals();
    _kdtree.reset(new pcl::KdTreeFLANN<PointS>);
    _kdtree->setInputCloud(_cloud_in);

    for(size_t i = 0; i < _cloud_in->points.size(); i++)
    {
        PointS p = _cloud_in->points.at(i);
        std::vector<int> pointIdxRadiusSearch;
        std::vector<float> pointRadiusSquaredDistance;
        if(_use_knn_search)
        {
            _kdtree->nearestKSearch(p,_k,pointIdxRadiusSearch, pointRadiusSquaredDistance);
        }
        else
        {
            _kdtree->radiusSearch(p,_range,pointIdxRadiusSearch,pointRadiusSquaredDistance);
        }


        Eigen::Matrix3f covariance_matrix;
        Eigen::Vector4f xyz_centroid;
        pcl::compute3DCentroid<PointS> (*_cloud_in, pointIdxRadiusSearch, xyz_centroid);
        pcl::computeCovarianceMatrix (*_cloud_in, pointIdxRadiusSearch, xyz_centroid, covariance_matrix);

        Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> eigen (covariance_matrix);
        float lambda1,lambda2,lambda3,sum;
        Eigen::Matrix<float,3,1> lambda = eigen.eigenvalues();
        lambda1 = lambda[0];
        lambda2 = lambda[1];
        lambda3 = lambda[2];

        sum = lambda1+lambda2+lambda3;
        lambda1 /= sum;
        lambda2 /= sum;
        lambda3 /= sum;

        _cloud_in->points.at(i).eigen1 = lambda1;
        _cloud_in->points.at(i).eigen2 = lambda2;
        _cloud_in->points.at(i).eigen3 = lambda3;

    }
}

void EnrichCloud::compute_normals()
{
    if(QThread::idealThreadCount()>1)
    {
        // Create the normal estimation class, and pass the input dataset to it
        pcl::NormalEstimationOMP<PointS, PointS> ne;
        ne.setInputCloud (_cloud_in);

        // Create an empty kdtree representation, and pass it to the normal estimation object.
        // Its content will be filled inside the object, based on the given input dataset (as no other search surface is given).
        pcl::search::KdTree<PointS>::Ptr tree (new pcl::search::KdTree<PointS> ());
        ne.setSearchMethod (tree);
        if(_use_knn_search)
        {
            ne.setKSearch(_k);
        }
        else
        {
            ne.setRadiusSearch(_range);
        }
        // Compute the features
        ne.compute (*_cloud_in);
    }
    else
    {
        // Create the normal estimation class, and pass the input dataset to it
        pcl::NormalEstimation<PointS, PointS> ne;
        ne.setInputCloud (_cloud_in);
        // Create an empty kdtree representation, and pass it to the normal estimation object.
        // Its content will be filled inside the object, based on the given input dataset (as no other search surface is given).
        pcl::search::KdTree<PointS>::Ptr tree (new pcl::search::KdTree<PointS> ());
        ne.setSearchMethod (tree);
        if(_use_knn_search)
        {
            qDebug() << "enrich wrong";
            ne.setKSearch(_k);
        }
        else
        {
            qDebug() << "enrich right";
            ne.setRadiusSearch(_range);
        }
        ne.compute (*_cloud_in);
    }

}

EnrichCloud::EnrichCloud(PointCloudS::Ptr cloud_in, int k , float range, bool use_knn )
{
    _cloud_in = cloud_in;
    _k = k;
    _range = range;
    _use_knn_search = use_knn;
    compute();
}
