#ifndef BINCLOUD_H
#define BINCLOUD_H

#include "SimpleTree4/model/pointsimpletree.h"
#include <QVector>
#include <QtCore/qmath.h>
#include <QDebug>

class BinCloud
{
    PointCloudS::Ptr _cloud_in;

    QVector<PointCloudS::Ptr> _clusters;

    float _bin_distance;



public:

    void fill_clusters();

    void generate_empty_clusters();

    BinCloud(PointCloudS::Ptr cloud_in, float bin_distance);

    QVector<PointCloudS::Ptr> get_clusters() const;
};

#endif // BINCLOUD_H
