#ifndef EXTRACTLOWESTCLUSTERS_H
#define EXTRACTLOWESTCLUSTERS_H

#include "SimpleTree4/model/pointsimpletree.h"

#include <pcl/filters/passthrough.h>
#include <pcl/filters/impl/passthrough.hpp>
#include "SimpleTree4/method/point_cloud_operations/clustercloud.h"

class ExtractLowestClusters
{
    PointCloudS::Ptr _cloud;

    QVector<PointCloudS::Ptr> clusters;
public:
    ExtractLowestClusters(PointCloudS::Ptr cloud, float height, float thresh);

    QVector<PointCloudS::Ptr> get_clusters() const;
};

#endif // EXTRACTLOWESTCLUSTERS_H
