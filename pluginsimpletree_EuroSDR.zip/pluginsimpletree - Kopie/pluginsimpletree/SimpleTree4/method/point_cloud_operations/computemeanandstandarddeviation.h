#ifndef COMPUTEMEANANDSTANDARDDEVIATION_H
#define COMPUTEMEANANDSTANDARDDEVIATION_H

#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>

#include "SimpleTree4/model/pointsimpletree.h"
#include <QVector>
#include <QSharedPointer>
#include <QDebug>



class ComputeMeanAndStandardDeviation
{
    PointCloudS::Ptr _cloud;
    std::vector<double> _average_distances;
    QSharedPointer<pcl::KdTreeFLANN<PointS> >_kdtree;

public:

    float _mean;
    float _sd;


    ComputeMeanAndStandardDeviation(PointCloudS::Ptr cloud);
};

#endif // COMPUTEMEANANDSTANDARDDEVIATION_H
