#ifndef CLUSTERCLOUD_H
#define CLUSTERCLOUD_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/math/simplemath.h"


#include <QVector>

#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/kdtree/impl/kdtree_flann.hpp>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/segmentation/impl/extract_clusters.hpp>

class ClusterCloud
{
    static const int _MIN_PTS = 3;
public:
    ClusterCloud();


    /**
     * @brief cluster Performs an euclidean clustering
     * @param cloud_in the input cloud
     * @param distance the min distance between two clusters
     * @return All clusters with at least _MIN_PTS points
     */
    static const QVector<PointCloudS::Ptr> cluster(PointCloudS::Ptr cloud_in, float distance);

    /**
     * @brief cluster Performs an euclidean clustering
     * @param cloud_in the input cloud
     * @param distance the min distance between two clusters
     * @return All clusters with at least _MIN_PTS points
     */
    static const QVector<PointCloudS::Ptr> cluster(PointCloudS::Ptr cloud_in, float distance, int min_pts);
};

#endif // CLUSTERCLOUD_H
