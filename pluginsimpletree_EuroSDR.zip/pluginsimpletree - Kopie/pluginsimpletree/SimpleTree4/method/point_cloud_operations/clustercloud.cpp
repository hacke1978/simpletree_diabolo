#include "clustercloud.h"

ClusterCloud::ClusterCloud()
{

}



const QVector<PointCloudS::Ptr> ClusterCloud::cluster(PointCloudS::Ptr cloud_in, float distance)
{
    QVector<PointCloudS::Ptr> clusters;
    if(cloud_in->points.size()>2)
    {
        pcl::search::KdTree<PointS>::Ptr tree (new pcl::search::KdTree<PointS>);
        tree->setInputCloud (cloud_in);

        std::vector<pcl::PointIndices> cluster_indices;
        pcl::EuclideanClusterExtraction<PointS> ec;
        ec.setClusterTolerance (distance); // 2cm
        ec.setSearchMethod (tree);
        ec.setInputCloud (cloud_in);
        ec.extract (cluster_indices);

        for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
        {
            pcl::PointCloud<PointS>::Ptr cloud_cluster (new pcl::PointCloud<PointS>);
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit)
                cloud_cluster->points.push_back (cloud_in->points[*pit]); //*
            cloud_cluster->width = cloud_cluster->points.size ();
            cloud_cluster->height = 1;
            cloud_cluster->is_dense = true;
            if(cloud_cluster->points.size()>_MIN_PTS)
            {
                clusters.push_back(cloud_cluster);
            }
        }
    }
    return clusters;
}

const QVector<PointCloudS::Ptr> ClusterCloud::cluster(PointCloudS::Ptr cloud_in, float distance, int min_pts)
{
    QVector<PointCloudS::Ptr> clusters;
    if(cloud_in->points.size()>2)
    {
        pcl::search::KdTree<PointS>::Ptr tree (new pcl::search::KdTree<PointS>);
        tree->setInputCloud (cloud_in);

        std::vector<pcl::PointIndices> cluster_indices;
        pcl::EuclideanClusterExtraction<PointS> ec;
        ec.setClusterTolerance (distance); // 2cm
        ec.setSearchMethod (tree);
        ec.setInputCloud (cloud_in);
        ec.extract (cluster_indices);

        for (std::vector<pcl::PointIndices>::const_iterator it = cluster_indices.begin (); it != cluster_indices.end (); ++it)
        {
            pcl::PointCloud<PointS>::Ptr cloud_cluster (new pcl::PointCloud<PointS>);
            for (std::vector<int>::const_iterator pit = it->indices.begin (); pit != it->indices.end (); ++pit)
                cloud_cluster->points.push_back (cloud_in->points[*pit]); //*
            cloud_cluster->width = cloud_cluster->points.size ();
            cloud_cluster->height = 1;
            cloud_cluster->is_dense = true;
            if(cloud_cluster->points.size()>min_pts)
            {
                clusters.push_back(cloud_cluster);
            }
        }
    }
    return clusters;
}
