#include "spheresurfaceextraction.h"

SphereSurfaceExtraction::SphereSurfaceExtraction()
{

}

const PointCloudS::Ptr SphereSurfaceExtraction::extract_sphere_surface(QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > octree,
                                                                       pcl::ModelCoefficients &sphere, PointCloudS::Ptr cloud_in, float epsilon_sphere)
{

    PointCloudS::Ptr cloud_out (new PointCloudS);
    PointS searchPoint;
    searchPoint.x = sphere.values[0];
    searchPoint.y = sphere.values[1];
    searchPoint.z = sphere.values[2];
    std::vector<int> pointIdxRadiusSearch;
    std::vector<float> pointRadiusSquaredDistance;
    float radius = sphere.values[3] + epsilon_sphere;
    float minSquaredDist = (sphere.values[3] - epsilon_sphere)
            * (sphere.values[3] - epsilon_sphere);
    float maxSquaredDist = (sphere.values[3] + epsilon_sphere)
            * (sphere.values[3] + epsilon_sphere);
    octree->radiusSearch(searchPoint, radius, pointIdxRadiusSearch,
            pointRadiusSquaredDistance);


    for (size_t i = 0; i < pointIdxRadiusSearch.size(); i++) {
        if (pointRadiusSquaredDistance[i] > minSquaredDist
                && pointRadiusSquaredDistance[i] < maxSquaredDist) {
            cloud_out->push_back(cloud_in->points[pointIdxRadiusSearch[i]]);
        }
        octree->deleteVoxelAtPoint(pointIdxRadiusSearch[i]);
    }
    return cloud_out;
}
