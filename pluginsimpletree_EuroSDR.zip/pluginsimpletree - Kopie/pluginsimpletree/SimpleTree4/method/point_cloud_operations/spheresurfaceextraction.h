#ifndef SPHERESURFACEEXTRACTION_H
#define SPHERESURFACEEXTRACTION_H

#include <SimpleTree4/model/pointsimpletree.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/octree/octree_search.h>
#include <pcl/octree/impl/octree_search.hpp>
#include <QVector>
#include <QSharedPointer>


class SphereSurfaceExtraction
{
public:
    SphereSurfaceExtraction();

    /**
     * @brief extract_sphere_surface Extracts from an input stored in an octree all spheres in the surface
     * @param octree The octree
     * @param sphere the sphere paramters
     * @param cloud_in The input cloud
     * @param epsilon_sphere The epsilon neighborhood of the sphere where the points should be extracted
     * @return The points on the surface
     */
    const static PointCloudS::Ptr extract_sphere_surface(QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > octree,
    pcl::ModelCoefficients& sphere, PointCloudS::Ptr cloud_in, float epsilon_sphere);
};

#endif // SPHERESURFACEEXTRACTION_H


