#ifndef PREDICTSTABLEVOLUME_H
#define PREDICTSTABLEVOLUME_H

#include "SimpleTree4/method/method_coefficients.h"
#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/math/simplemath.h"

#include <pcl/sample_consensus/method_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/impl/sac_segmentation.hpp>
#include <pcl/filters/passthrough.h>
#include <pcl/filters/impl/passthrough.hpp>

#include <QDebug>



class PredictStableVolume
{
    PointCloudS::Ptr _cloud;

    MethodCoefficients _coeff;

    float _minZ = std::numeric_limits<float>::max();

    void predict_height();

    void predict_circumference();

    void predict_volume();

    PointCloudS::Ptr extract_low_cluster();

    PointCloudS::Ptr filter_low_cluster(PointCloudS::Ptr cloud_unfiltered);

    float predict_cylinder_radius(PointCloudS::Ptr cloud);

    float get_circumference_from_radius(float radius);

public:

    PredictStableVolume(PointCloudS::Ptr cloud, MethodCoefficients coeff);

    MethodCoefficients get_coeff() const;
};

#endif // PREDICTSTABLEVOLUME_H
