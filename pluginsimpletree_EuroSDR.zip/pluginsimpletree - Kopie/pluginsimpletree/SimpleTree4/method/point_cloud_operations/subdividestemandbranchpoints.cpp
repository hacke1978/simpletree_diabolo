#include "subdividestemandbranchpoints.h"

SubdivideStemAndBranchPoints::SubdivideStemAndBranchPoints()
{

}

void SubdivideStemAndBranchPoints::subdivide_points(PointCloudS::Ptr cloud_in, PointCloudS::Ptr cloud_stem, PointCloudS::Ptr cloud_branch)
{
    for(int i = 0; i < cloud_in->points.size(); i++)
    {
        if(cloud_in->points.at(i).is_stem>0.5)
        {
            cloud_stem->push_back(cloud_in->points.at(i));
        } else
        {
            cloud_branch->push_back(cloud_in->points.at(i));
        }
    }
    cloud_stem->width = cloud_stem->points.size();
    cloud_stem->height = 1;


    cloud_branch->width = cloud_branch->points.size();
    cloud_branch->height = 1;
}
