#include "bincloud.h"

QVector<PointCloudS::Ptr> BinCloud::get_clusters() const
{
    return _clusters;
}

void BinCloud::fill_clusters()
{
    size_t size = _cloud_in->points.size();
    for(size_t i = 0; i < size; i++)
    {
        float dist = _cloud_in->points.at(i).distance;
        int cluster_ID = qFloor(dist/_bin_distance);

        _clusters[cluster_ID]->push_back(_cloud_in->points.at(i));
        _cloud_in->points[i].rangebin = cluster_ID;
    }
}

void BinCloud::generate_empty_clusters()
{
    float max_dist = 0;
    size_t size = _cloud_in->points.size();
    for(size_t i = 0; i < size; i++)
    {
        float dist = _cloud_in->points.at(i).distance;
        if(_cloud_in->points.at(i).distance > max_dist)
        {
            max_dist = _cloud_in->points.at(i).distance;
        }
    }
    int number = qFloor(max_dist/_bin_distance)+1;
    for(int i = 0; i < number; i++)
    {
        PointCloudS::Ptr cloud (new PointCloudS);
        _clusters.push_back(cloud);
    }

}

BinCloud::BinCloud(PointCloudS::Ptr cloud_in, float bin_distance): _cloud_in(cloud_in), _bin_distance(bin_distance)
{
    generate_empty_clusters();
    fill_clusters();
}
