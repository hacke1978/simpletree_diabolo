#ifndef OPTIMIZATIONSPHEREFOLLOWING_H
#define OPTIMIZATIONSPHEREFOLLOWING_H


#include <QEnableSharedFromThis>
#include <QVector>

#include <SimpleTree4/model/pointsimpletree.h>
#include <SimpleTree4/method/method_coefficients.h>
#include <SimpleTree4/method/workerspherefollowing.h>
#include <SimpleTree4/model/build_tree/buildtree.h>
#include <SimpleTree4/model/build_tree/improvebymedian.h>
#include <SimpleTree4/model/build_tree/removefalsecylinders.h>
#include <SimpleTree4/model/build_tree/improvebymerge.h>
#include <SimpleTree4/model/build_tree/reordertree.h>


class OptimizationSphereFollowing : public QObject, public QEnableSharedFromThis<OptimizationSphereFollowing>
{
    Q_OBJECT

    PointCloudS::Ptr _cloud;

    MethodCoefficients _coeff;

    float _best_distance = 50;

    QVector<MethodCoefficients>
    generate_coefficients();

    bool _subdivide_stem_and_branch_points;

    bool _is_multithreaded;




public:

    MethodCoefficients _coeff_end;

    OptimizationSphereFollowing(PointCloudS::Ptr cloud, MethodCoefficients coeff, bool subdivide_stem_and_branch_points, bool is_multithreaded = true);

    void
    update_coeff(MethodCoefficients coeff, float distance);

    void
    optimize();
};

#endif // OPTIMIZATIONSPHEREFOLLOWING_H
