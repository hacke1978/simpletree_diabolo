#include "workerfit.h"

WorkerFit::WorkerFit(MethodCoefficients coeff, PointCloudS::Ptr cloud, QSharedPointer<OptimizationFit> optim,  QVector<pcl::ModelCoefficients> cylinder_coeff)
{
    _cloud = cloud;
    _coeff = coeff;
    _optim = optim;
    _cylinder_coeff = cylinder_coeff;
}


void
WorkerFit::run()
{


    BuildTree builder(_cylinder_coeff);
    QSharedPointer<Tree> tree (new Tree(builder.getRoot_segment(), _coeff.id));
    RemoveFalseCylinders remove(tree);
    ImproveByMedian improve_by_median(tree);
    ImproveByMerge improve_merge(tree);
    ImproveByPipeModel pype(tree);
    ImproveFit fit(tree,_cloud,_coeff);



    QVector<QSharedPointer<Cylinder> > cylinders = tree->get_all_cylinders();
    QVector<pcl::ModelCoefficients> cylinder_coefficients;
    QVectorIterator<QSharedPointer<Cylinder> > it(cylinders);
    while(it.hasNext())
    {
        QSharedPointer<Cylinder> cylinder = it.next();
        pcl::ModelCoefficients coefficients;
        coefficients.values = cylinder->values;
        cylinder_coefficients.push_back(coefficients);
    }

    ComputeDistanceCylindersCloud cd (cylinder_coefficients,_cloud);
    float dist = cd.get_mean_sqrd_dist();
    _optim->update_coeff(_coeff, dist,tree);
}
