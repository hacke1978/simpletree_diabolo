#include "computedistancecylinderscloud.h"



QVector<double> ComputeDistanceCylindersCloud::get_distances_double() const
{
    return _distances_double;
}

QVector<double> ComputeDistanceCylindersCloud::get_distances_double_sqrd() const
{
    return _distances_double_sqrd;
}

QVector<float> ComputeDistanceCylindersCloud::get_distances_float() const
{
    return _distances_float;
}

QVector<float> ComputeDistanceCylindersCloud::get_distances_float_sqrd() const
{
    return _distances_float_sqrd;
}

float ComputeDistanceCylindersCloud::get_mean_sqrd_dist() const
{
    if(_distance_sqrd>1e-40)
    {
        return _distance_sqrd;
    }
    float x = 1.0+ ((qrand()/100.0))/1000.0;
    qDebug() << "computedistancecylinderscloud the distance" << x << "number cylinders " << _cylinders.size();
    return x;
}



float ComputeDistanceCylindersCloud::get_mean_dist() const
{
    if(_distance>1e-40)
    {
        return _distance;
    }
    float x = 1.0+ ((qrand()/100.0))/1000.0;
    qDebug() << "computedistancecylinderscloud the distance" << x << "number cylinders " << _cylinders.size();
    return x;
}

float ComputeDistanceCylindersCloud::get_mean_sqrd_dist_normal() const
{
    if(_distance_sqrd_normal>1e-40)
    {
//        return _distance_sqrd;
        return _distance_sqrd_normal;
    }
    float x = 1.0+ ((qrand()/100.0))/1000.0;
    qDebug() << "computedistancecylinderscloud the distance" << x << "number cylinders " << _cylinders.size() << " length vector" << _distances_double_sqrd_normal.size() << " vvalue " << _distance_sqrd_normal;
    return x;
}

float ComputeDistanceCylindersCloud::get_sd_sqrd_dist() const
{
    if(_standard_deviation_sqrd>1e-40)
    {
        return _standard_deviation_sqrd;
    }
    float x = 1.0+ ((qrand()/100.0))/1000.0;
    qDebug() << "computedistancecylinderscloud the distance" << x << "number cylinders " << _cylinders.size();
    return x;
}

float ComputeDistanceCylindersCloud::get_sd_dist() const
{
    if(_standard_deviation>1e-40)
    {
        return _standard_deviation;
    }
    float x = 1.0+ ((qrand()/100.0))/1000.0;
    qDebug() << "computedistancecylinderscloud the distance" << x << "number cylinders " << _cylinders.size();
    return x;
}









void ComputeDistanceCylindersCloud::compute_distances()
{
    float max_unfitted_distance = SimpleMath<float>::_UNFITTED_DISTANCE;
    _distances_float_sqrd.fill(max_unfitted_distance*max_unfitted_distance,_cloud->points.size());
    _distances_float.fill(max_unfitted_distance,_cloud->points.size());
    _distances_double_sqrd.fill(max_unfitted_distance*max_unfitted_distance,_cloud->points.size());
    _distances_double_sqrd_normal.fill(max_unfitted_distance*max_unfitted_distance,_cloud->points.size());
    _distances_double.fill(max_unfitted_distance,_cloud->points.size());
    QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > octree(new  pcl::octree::OctreePointCloudSearch<PointS> ( SimpleMath<float>::_OCTREE_RESOLUTION )) ;
    octree->setInputCloud ( _cloud );
    octree->addPointsFromInputCloud ();
    QVectorIterator<QSharedPointer<Cylinder> > it (_cylinders);
    while(it.hasNext())
    {
        QSharedPointer<Cylinder> cylinder = it.next();
        std::vector<int> indices = extract_points_near_cylinder( cylinder,  octree);
        for ( size_t i = 0; i < indices.size (); i++ ) {
            PointS point = _cloud->points[indices[i]];
            QSharedPointer<PointS> p (new PointS);
            p->x = point.x;
            p->y = point.y;
            p->z = point.z;

            float dist = cylinder->dist_to_point_ptr(p);

            if ( std::abs ( dist*dist ) < std::abs ( _distances_float_sqrd[indices[i]] ) ) {
                _distances_float_sqrd[indices[i]] = std::abs(dist*dist);
                _distances_float[indices[i]] = std::abs(dist);
                _distances_double_sqrd[indices[i]] = std::abs(dist*dist);
                _distances_double[indices[i]] = std::abs(dist);
                Eigen::Vector3f cylinder_axis;
                cylinder_axis[0] = cylinder->values[3];
                cylinder_axis[1] = cylinder->values[4];
                cylinder_axis[2] = cylinder->values[5];
                Eigen::Vector3f point_normal;
                point_normal[0] = point.normal_x;
                point_normal[1] = point.normal_y;
                point_normal[2] = point.normal_z;
                double angle_deg = SimpleMath<float>::angle_between(cylinder_axis,point_normal);
                angle_deg = std::abs(angle_deg -90);
                if(std::isnan(angle_deg))
                {
                    angle_deg = 90;
                }
                //                qDebug() << angle_deg;
                //                if(angle_deg >= 90 )

                //                {
                //                    angle_deg = 180 - angle_deg;
                //                if(angle_deg <= 0 || angle_deg >= 90)
                //                {
                //                    qDebug() << "wrong angle in ComputeDistanceCylindersCloud::compute_distances()" << angle_deg;
                //                }
                //                }

                //                angle_deg += 1;
                if(angle_deg == 0)
                {
                    angle_deg = 0.00001;
                }
                _distances_double_sqrd_normal[indices[i]] = std::abs(dist*dist)/angle_deg;
            }
        }
    }
    _distance = SimpleMath<double>::get_mean(_distances_double);
    _distance_sqrd = SimpleMath<double>::get_mean(_distances_double_sqrd);
    _distance_sqrd_normal = SimpleMath<double>::get_mean(_distances_double_sqrd_normal);
    _standard_deviation = SimpleMath<double>::get_standard_deviation(_distances_double);
    _standard_deviation_sqrd = SimpleMath<double>::get_standard_deviation(_distances_double_sqrd);
}




std::vector<int> ComputeDistanceCylindersCloud::extract_points_near_cylinder(QSharedPointer<Cylinder> cylinder, QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > octree)
{
    PointCloudS::Ptr output_cloud (new PointCloudS);
    QSharedPointer<PointS> query_point = cylinder->get_center_ptr();
    float cylinder_size = cylinder->get_half_size();
    float radius = qMax<float>(cylinder_size + _MIN_DIST_TO_CYLINDER, cylinder_size* _CYLINDER_SIZE_MULTIPLIER);
    std::vector<int> pointIdxRadiusSearch;
    std::vector<float> pointRadiusSquaredDistance;
    octree->radiusSearch (*query_point, radius, pointIdxRadiusSearch, pointRadiusSquaredDistance);
    output_cloud->points.resize(pointIdxRadiusSearch.size());
    return pointIdxRadiusSearch;

}

ComputeDistanceCylindersCloud::ComputeDistanceCylindersCloud(QVector<pcl::ModelCoefficients> cylinder_coeff, PointCloudS::Ptr cloud)
{
    _cylinders.resize(cylinder_coeff.size());
    for(int i =0 ; i< cylinder_coeff.size(); i++)
    {
        QSharedPointer<Cylinder> cylinder (new Cylinder(cylinder_coeff.at(i)));
        _cylinders[i] = cylinder;
    }
    _cloud = cloud;
    compute_distances();
}

ComputeDistanceCylindersCloud::ComputeDistanceCylindersCloud(QSharedPointer<Tree> tree, PointCloudS::Ptr cloud)
{
    _cylinders = tree->get_all_cylinders();
    _cloud = cloud;
    compute_distances();
}



ComputeDistanceCylindersCloud::ComputeDistanceCylindersCloud(QSharedPointer<Cylinder> cylinder, PointCloudS::Ptr cloud)
{
    _cylinder = cylinder;
    _distances_double_sqrd.clear();

    for(size_t i = 0; i < cloud->points.size(); i++)
    {
        PointS point = cloud->points[i];
        QSharedPointer<PointS> p (new PointS);
        p->x = point.x;
        p->y = point.y;
        p->z = point.z;
        double dist = cylinder->dist_to_point_ptr(p);
        _distances_double_sqrd.push_back(dist*dist);
    }

    _distance = SimpleMath<double>::get_mean(_distances_double);
    _distance_sqrd = SimpleMath<double>::get_mean(_distances_double_sqrd);
    _standard_deviation = SimpleMath<double>::get_standard_deviation(_distances_double);
    _standard_deviation_sqrd = SimpleMath<double>::get_standard_deviation(_distances_double_sqrd);
}




