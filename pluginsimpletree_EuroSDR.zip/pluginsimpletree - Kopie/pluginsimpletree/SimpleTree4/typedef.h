#ifndef TYPEDEF_H
#define TYPEDEF_H

#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include "model/pointsimpletree.h"

typedef PointSimpleTree PointS;
typedef pcl::PointCloud<PointS> PointCloudS;

#endif // TYPEDEF_H
