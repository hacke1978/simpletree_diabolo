#ifndef IMPROVEDBYADVANCEDMEDIAN_H
#define IMPROVEDBYADVANCEDMEDIAN_H

#include "SimpleTree4/model/tree.h"



class ImprovedByAdvancedMedian
{

    const static float _MAX_PERCENTAGE;

    const static float _MIN_PERCENTAGE;

    QSharedPointer<Tree> _tree;

    void
    improve_segment(QSharedPointer<Segment> segment);

    void
    smooth_segment(QSharedPointer<Segment> segment);

    void
    improve();

    void
    smooth();

    QVector<int> _indices;
public:
    ImprovedByAdvancedMedian(QSharedPointer<Tree> tree);
};

#endif // IMPROVEDBYADVANCEDMEDIAN_H
