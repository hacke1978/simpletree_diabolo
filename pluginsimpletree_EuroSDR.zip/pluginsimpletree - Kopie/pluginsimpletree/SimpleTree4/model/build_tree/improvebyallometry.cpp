#include "improvebyallometry.h"

void ImproveByAllometry::improve()
{
    //MethodCoefficients coeff;
    QVector<float> growth_volumina;
    QVector<QSharedPointer<Cylinder> > cylinders = _tree->get_all_cylinders();
    QVectorIterator<QSharedPointer<Cylinder> > it(cylinders);
    while(it.hasNext())
    {
        QSharedPointer<Cylinder> cylinder = it.next();
        float y = _tree->get_growth_volume(cylinder);
        growth_volumina.push_back(y);
    }
    float length = _tree->get_length(_cf);
    for(size_t i = 0; i < cylinders.size(); i++)
    {
        QSharedPointer<Cylinder> cylinder = cylinders.at(i);
        float x = cylinder->get_radius();
        float y = growth_volumina.at(i);
        float x2 = get_x_from_y(y);
        float ratio = x/x2;

        if(!cylinder->get_segment()->is_root())
        {
            if(y<(get_y_from_x(x)/_fac) )
            {
                if(ratio > _cf.ratio_min)
                {
                    cylinder->set_radius(get_x_from_y(y));
                    cylinder->set_allometry_improvement(AllometryImproved::ALLOM);
                } else {
                    if (length < 10){
                       cylinder->set_radius(get_x_from_y(y));
                       cylinder->set_allometry_improvement(AllometryImproved::ALLOM);
                    }

                }
            }

            if(cylinder->get_radius()<_min_rad)
            {
                cylinder->set_radius(_min_rad);
            }
        }
    }
}

float ImproveByAllometry::get_y_from_x(float x)
{
    float y = _a * (pow (x,_b));
    return y;
}

float ImproveByAllometry::get_x_from_y(float y)
{
    float log_x = (log(y/_a))/(_b);

    float x = exp(log_x);
    return x;
}


ImproveByAllometry::ImproveByAllometry(QSharedPointer<Tree> tree, MethodCoefficients cf,float a, float b, float fac, bool inverse)
{
    _tree = tree;
    _cf = cf;
    _a = a;
    _b = b;
    _fac = fac;
    _inverse = inverse;
    _min_rad = cf.min_rad;
    improve();
}
