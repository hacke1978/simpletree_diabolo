#ifndef IMPROVEBYATTRACTOR_H
#define IMPROVEBYATTRACTOR_H

#include "SimpleTree4/method/geometrical_operations/extractfittedpoints.h"
#include "SimpleTree4/method/point_cloud_operations/clustercloud.h"
#include "SimpleTree4/method/point_cloud_operations/voxelgridfilter.h"

struct Triplet
{
    PointS attr;
    PointS end;
    float dist;
};


Q_DECLARE_METATYPE(Triplet)

class ImproveByAttractor
{
    float _clustering_distance = 0.075f;

    float _min_dist_downscale = 0.2f;

    int _min_pts_cluster = 9;

    QList<QVariant> _list;

    void remove_attractor(PointS &attr);

    void initiate_list();

    PointCloudS::Ptr generate_end_point_cloud(QVector<pcl::ModelCoefficients> coeff);

    PointCloudS::Ptr generate_attractor_cloud(PointCloudS::Ptr cloud);

    void update_list(PointS &p);

    QPair<PointS, PointS> find_pair();

    PointCloudS::Ptr _end_pts;

    PointCloudS::Ptr _attractors;

    MethodCoefficients _coeff;

    PointCloudS::Ptr _cloud;

    PointCloudS::Ptr _remaining_cloud;

    QVector<pcl::ModelCoefficients> _cylinders;

    QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > _octree;

public:
    ImproveByAttractor(PointCloudS::Ptr cloud,PointCloudS::Ptr remaining_cloud, MethodCoefficients coeff,     QVector<pcl::ModelCoefficients> get_cylinders);

    QVector<pcl::ModelCoefficients> get_cylinders() const;

    MethodCoefficients get_coeff() const;
};

#endif // IMPROVEBYATTRACTOR_H
