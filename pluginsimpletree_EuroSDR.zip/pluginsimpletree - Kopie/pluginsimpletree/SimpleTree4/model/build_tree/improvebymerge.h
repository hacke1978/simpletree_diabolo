#ifndef IMPROVEBYMERGE_H
#define IMPROVEBYMERGE_H

#include "SimpleTree4/math/simplemath.h"
#include "SimpleTree4/model/tree.h"

#include <QSharedPointer>

class ImproveByMerge
{
    QSharedPointer<Tree> _tree;

    void
    improve();
public:
    ImproveByMerge(QSharedPointer<Tree> tree);
};

#endif // IMPROVEBYMERGE_H
