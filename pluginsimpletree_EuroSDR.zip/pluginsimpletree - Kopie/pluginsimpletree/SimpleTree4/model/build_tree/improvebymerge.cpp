#include "improvebymerge.h"

void ImproveByMerge::improve()
{
    QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
    QVectorIterator<QSharedPointer<Segment> > it(segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> segment = it.next();
        while(segment->get_mean_length()<1*(SimpleMath<float>::_MIN_CYLINDER_LENGTH)&&segment->get_cylinders().size()>1)
        {
            QVector<QSharedPointer<Cylinder> > cylinders = segment->get_cylinders();
            QVector<QSharedPointer<Cylinder> >  cylinders_new;
            QVectorIterator<QSharedPointer<Cylinder> > git (cylinders);
            while(git.hasNext())
            {
                QSharedPointer<Cylinder> cylinder1 = git.next();
                if(git.hasNext())
                {
                    QSharedPointer<Cylinder> cylinder2 = git.next();

                    float x1_start = cylinder1->get_start_ptr()->x;
                    float y1_start = cylinder1->get_start_ptr()->y;
                    float z1_start = cylinder1->get_start_ptr()->z;
                    float x2_end = cylinder2->get_end_ptr()->x;
                    float y2_end = cylinder2->get_end_ptr()->y;
                    float z2_end = cylinder2->get_end_ptr()->z;
                    float radius = (cylinder1->get_radius()+cylinder2->get_radius())/2;
                    float x_axis = x2_end-x1_start;
                    float y_axis = y2_end-y1_start;
                    float z_axis = z2_end-z1_start;
                    pcl::ModelCoefficients cf;
                    cf.values.push_back(x1_start);
                    cf.values.push_back(y1_start);
                    cf.values.push_back(z1_start);
                    cf.values.push_back(x_axis);
                    cf.values.push_back(y_axis);
                    cf.values.push_back(z_axis);
                    cf.values.push_back(radius);
                    QSharedPointer<Cylinder> cylinder_new (new Cylinder(cf));
                    cylinders_new.push_back(cylinder_new);
                } else
                {
                    cylinders_new.push_back(cylinder1);
                }

            }
            segment->set_cylinders(cylinders_new);
        }
    }
}

ImproveByMerge::ImproveByMerge(QSharedPointer<Tree> tree)
{
    _tree = tree;
    improve();
}
