#include "reordertree.h"

float ReorderTree::get_maximum_volume_to_leave(QSharedPointer<Segment> seg)
{
    QSharedPointer<Tree> tree (new Tree(seg,"tree"));
    QVector<float> volumina;
    QVector<QSharedPointer<Segment> > segments = tree->get_leave_segments(seg);
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment>  leaf = it.next();
        float volume = tree->get_volume_to_base(leaf, seg);
        volumina.push_back(volume);
    }
    float result = *(std::max_element(volumina.begin(), volumina.end()));
    return result;
}

bool ReorderTree::compareSegments(QSharedPointer<Segment> seg1, QSharedPointer<Segment> seg2)
{

    float volume1 = get_maximum_volume_to_leave(seg1);
    float volume2 = get_maximum_volume_to_leave(seg2);
    return(volume2<volume1);
}

bool ReorderTree::compareStemSegments(QSharedPointer<Segment> seg1, QSharedPointer<Segment> seg2)
{
    return(seg2->get_branch_order()<seg1->get_branch_order());
}

void ReorderTree::reorder()
{

    QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> segment = it.next();
        segment->set_branch_id(-1);
        segment->set_branch_order(-1);
        segment->set_id(-1);

    }
    QSharedPointer<Segment> top_segment = detect_top_segment();
    recursive_stem_tagging(top_segment);


    QVectorIterator<QSharedPointer<Segment> > git (segments);
    while(git.hasNext())
    {
        QSharedPointer<Segment> segment = git.next();


        if(segment->get_child_segments().size()>1)
        {
            QVector<QSharedPointer<Segment> > children = segment->get_child_segments();

            if(segment->get_branch_order()==0)
            {
                std::sort(children.begin(), children.end(), compareStemSegments);
            } else
            {
                std::sort(children.begin(), children.end(), compareSegments);
            }


            segment->set_child_segments(children);
        }
    }
}

void ReorderTree::fill_IDs()
{
    QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    int segment_ID = 0;
    while(it.hasNext())
    {
        QSharedPointer<Segment> segment = it.next();
        segment->set_id(segment_ID);
        segment_ID++;
    }
    generate_branch_order(_tree->get_root_segment(),0);
    generate_branch_ID();
}

void ReorderTree::set_cylinder_ID()
{
    QVector<QSharedPointer<Cylinder> > cylinders = _tree->get_all_cylinders();
    size_t index = 0;
    for(index = 0; index < cylinders.size(); index++)
    {
        QSharedPointer<Cylinder> cylinder = cylinders.at(index);
        cylinder->setID(index);
    }
    for(index = 0; index < cylinders.size(); index++)
    {
        QSharedPointer<Cylinder> cylinder = cylinders.at(index);
//        cylinder->setID(index);
        QSharedPointer<Cylinder> parent = _tree->get_parent(cylinder);
        if(parent != cylinder)
            cylinder->setParent_ID(parent->getID());
    }
}

void ReorderTree::recursive_stem_tagging(QSharedPointer<Segment> seg)
{
    seg->set_branch_order(0);
    if(seg!=_tree->get_root_segment())
        recursive_stem_tagging(seg->get_parent_segment());
}

void ReorderTree::generate_reverse_pipe_bo(QSharedPointer<Segment> seg)
{
    if(seg->is_leave())
    {
        seg->setReverse_pipe_order(1);
    } else {
        QVector<QSharedPointer<Segment> > children = seg->get_child_segments();

        float order = 0;
        QVectorIterator<QSharedPointer<Segment> > it (children);
        while(it.hasNext())
        {
            QSharedPointer<Segment> child = it.next();
            generate_reverse_pipe_bo(child);
            order += child->getReverse_pipe_order()*child->getReverse_pipe_order();
        }
        order = std::sqrt(order);
        seg->setReverse_pipe_order(order);
    }
}

QSharedPointer<Segment> ReorderTree::detect_top_segment()
{
    QVector<QSharedPointer<Segment> > leave_segments = _tree->get_leave_segments(_tree->get_root_segment());
    QVectorIterator<QSharedPointer<Segment> > it (leave_segments);
    QSharedPointer<Segment> top_segment;
    float max_height = std::numeric_limits<float>::lowest();
    while(it.hasNext())
    {
        QSharedPointer<Segment> leave = it.next();
        float height = leave->get_cylinders().last()->get_end().z;
        if(height > max_height)
        {
            max_height = height;
            top_segment = leave;
        }
    }
    return top_segment;
}

void ReorderTree::generate_branch_order(QSharedPointer<Segment> segment, int branch_order)
{
    segment->set_branch_order(branch_order);
    QVector<QSharedPointer<Segment> > children = segment->get_child_segments();
    QVectorIterator<QSharedPointer<Segment> > it (children);
    bool first = true;
    while(it.hasNext())
    {
        QSharedPointer<Segment> child = it.next();
        if(first)
        {
            generate_branch_order(child, branch_order);
        } else
        {
            generate_branch_order(child, branch_order+1);
        }
        first = false;
    }
}

QVector<QSharedPointer<Segment> > ReorderTree::get_stem()
{
    QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
    QVector<QSharedPointer<Segment> > stem_segments;
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> segment = it.next();
        if(segment->get_branch_order()==0)
        {
            stem_segments.push_back(segment);
        }


    }
    return stem_segments;
}

QVector<QSharedPointer<Segment> > ReorderTree::get_branch_roots()
{
    QVector<QSharedPointer<Segment> > stem_segments = get_stem();
    QVector<QSharedPointer<Segment> > branch_roots;
    QVectorIterator<QSharedPointer<Segment> > it(stem_segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> stem_segment = it.next();
        QVector<QSharedPointer<Segment> > children = stem_segment->get_child_segments();
        QVectorIterator<QSharedPointer<Segment> > git(children);
        bool first = true;
        while(git.hasNext())
        {
            QSharedPointer<Segment> child = git.next();
            if(!first)
            {
                branch_roots.push_back(child);
            }
            first = false;
        }
    }
    return branch_roots;
}

void ReorderTree::generate_branch_ID()
{
    QVector<QSharedPointer<Segment> > branch_roots = get_branch_roots();
    int index = 1;
    QVectorIterator<QSharedPointer<Segment> > it(branch_roots);
    while(it.hasNext())
    {
        QSharedPointer<Segment> branch_root = it.next();
        branch_root->set_branch_id(index);
        QVector<QSharedPointer<Segment> > complete_branch = branch_root->get_child_segments_recursively();
        QVectorIterator<QSharedPointer<Segment> >  git (complete_branch);
        while(git.hasNext())
        {
            QSharedPointer<Segment> branch = git.next();
            branch->set_branch_id(index);

        }
        index++;

    }
}





ReorderTree::ReorderTree(QSharedPointer<Tree> tree)
{
    _tree = tree;
    reorder();
    fill_IDs();
    set_cylinder_ID();
    generate_reverse_pipe_bo(tree->get_root_segment());
}
