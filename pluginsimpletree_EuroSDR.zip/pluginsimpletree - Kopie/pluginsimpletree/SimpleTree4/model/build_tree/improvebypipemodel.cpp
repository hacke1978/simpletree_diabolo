#include "improvebypipemodel.h"

void ImproveByPipeModel::improve()
{
  //  qDebug() << " ImproveByPipeModel::improve()";
    QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    while(it.hasNext())
    {

        QSharedPointer<Segment> seg = it.next();
        if(seg->get_mean_radius()<0.0001)
        {

            if(!seg->is_root())
            {
                float radius_parent = seg->get_parent_segment()->get_median_radius();
                float length_seg;// = _tree->get_growth_length(seg);
                QSharedPointer<Cylinder> cylinder = seg->get_cylinders().at(0);
                length_seg = _tree->get_length_to_leave(cylinder);
                QVector<QSharedPointer<Segment> > siblings = seg->get_parent_segment()->get_child_segments();
                QVectorIterator<QSharedPointer<Segment> > bit(siblings);
                float sum_length = 0;
                while(bit.hasNext())
                {
                    QSharedPointer<Segment> sibling = bit.next();
                    QSharedPointer<Cylinder> cylinder = sibling->get_cylinders().at(0);

                    sum_length += _tree->get_length_to_leave(cylinder);
                }
                float length_all_children;// = _tree->get_growth_length(seg->get_parent_segment()) - seg->get_parent_segment()->get_length();
                length_all_children = sum_length;
                if(length_all_children==0)
                {
                    qDebug() << "ImproveByPipeModel::improve()";
                }

                float radius_child = radius_parent*(std::pow( (length_seg/length_all_children),(1/2.49) )  );
                QVector<QSharedPointer<Cylinder> > cylinders = seg->get_cylinders();
                QVectorIterator<QSharedPointer<Cylinder> > git (cylinders);
                while(git.hasNext())
                {
                    QSharedPointer<Cylinder> cylinder = git.next();
                    cylinder->set_radius(radius_child);
                    cylinder->set_detection(DetectionType::ATTRACTOR);
                }
            }
        }
    }


}

ImproveByPipeModel::ImproveByPipeModel(QSharedPointer<Tree> tree)
{
    _tree = tree;
    improve();
}
