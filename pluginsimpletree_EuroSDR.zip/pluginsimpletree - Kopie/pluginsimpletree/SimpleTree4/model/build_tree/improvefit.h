#ifndef IMPROVEFIT_H
#define IMPROVEFIT_H

#include "../tree.h"

#include <pcl/point_cloud.h>
#include <pcl/octree/octree.h>
#include <pcl/octree/octree_impl.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>

#include <Eigen/Dense>

#include <SimpleTree4/math/simplemath.h>
#include <SimpleTree4/method/method_coefficients.h>
#include <SimpleTree4/method/geometrical_operations/cylinderfit.h>

class ImproveFit
{
private:

    MethodCoefficients _coeff;
    QSharedPointer<Tree> _tree;
    QSharedPointer<pcl::octree::OctreePointCloudSearch<PointS> > _octree;
    PointCloudS::Ptr _cloud;


    const static float _MIN_DIST_TO_CYLINDER;
    const static float _CYLINDER_SIZE_MULTIPLIER;


    const bool
    is_perpendicular(PointS p,  QSharedPointer<Cylinder> const cylinder);

public:
    ImproveFit(QSharedPointer<Tree> tree, PointCloudS::Ptr cloud, MethodCoefficients coeff);

    /**
     * @brief allocate_points Writes an ID for each point if fitted by a cylinder;
     */
    QVector<PointCloudS::Ptr>   allocate_points();

    /**
     * @brief allocate_points Writes an ID for each point if fitted by a cylinder;
     */
    QVector<PointCloudS::Ptr>   allocate_segment_points();




    /**
     * @brief extract_points_near_cylinder Returns a point cloud with the points near the cylinder
     * @param cylinder the input cylinder
     * @return the cloud
     */
    PointCloudS::Ptr
    extract_points_near_cylinder(QSharedPointer<Cylinder> cylinder);
    /**
     * @brief improve Iterates through all the cylinders and improves those by either RANSAC or Median method
     */
    void
    improve();

    /**
     * @brief RANSAC does a RANSAC Improvement
     * @param cloud the input cloud
     * @return the cylinder RANSAC coefficients
     */
    pcl::ModelCoefficients
    RANSAC(PointCloudS::Ptr cloud);

    /**
     * @brief improve_with_RANSAC Applies the RANSAC coeffiencts to the cylinder
     * @param cylinder the original cylinder
     * @param coeff the RANSAC coefficients
     */
    void
    improve_with_RANSAC(QSharedPointer<Cylinder> cylinder, pcl::ModelCoefficients coeff);

    /**
     * @brief improve_with_median Improves the radius of the cylinder with the median method
     * @param cylinder the input cylinder
     * @param cloud the cloud to compute the median from.
     */
    void
    improve_with_median(QSharedPointer<Cylinder> cylinder, PointCloudS::Ptr cloud);
};

#endif // IMPROVEFIT_H
