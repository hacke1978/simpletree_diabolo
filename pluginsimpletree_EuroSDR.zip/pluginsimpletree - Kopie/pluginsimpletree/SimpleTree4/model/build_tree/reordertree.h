#ifndef REORDERTREE_H
#define REORDERTREE_H

#include <algorithm>

#include "../tree.h"


class ReorderTree
{
private:
    QSharedPointer<Tree> _tree;

    static float
    get_maximum_volume_to_leave(QSharedPointer<Segment> seg);

    static bool
    compareSegments(QSharedPointer<Segment> seg1, QSharedPointer<Segment> seg2);

    static bool
    compareStemSegments(QSharedPointer<Segment> seg1, QSharedPointer<Segment> seg2);

    void
    reorder();

    void
    fill_IDs();

    void set_cylinder_ID();

    void recursive_stem_tagging(QSharedPointer<Segment> seg);

    void generate_reverse_pipe_bo(QSharedPointer<Segment> seg);


    QSharedPointer<Segment> detect_top_segment();

    void
    generate_branch_order(QSharedPointer<Segment> segment, int branch_order);

    QVector<QSharedPointer<Segment> >
    get_stem();

    QVector<QSharedPointer<Segment> >
    get_branch_roots();

    void
    generate_branch_ID();
public:
    ReorderTree(QSharedPointer<Tree> tree);
};

#endif // REORDERTREE_H
