#ifndef IMPROVEBYALLOMETRYLENGTH_H
#define IMPROVEBYALLOMETRYLENGTH_H

#include "SimpleTree4/math/simplemath.h"
#include "SimpleTree4/model/tree.h"


class ImproveByAllometryLength
{

    QSharedPointer<Tree> _tree;

    float _a;
    float _b;

    float _a_length;
    float _b_length;

    float _fac;
    float _min_rad;


    void
    improve();

    float get_y_from_x(float x);
    float get_x_from_y(float y);
    MethodCoefficients _cf;

public:
    ImproveByAllometryLength(QSharedPointer<Tree> tree, MethodCoefficients cf, float a, float b, float a_length, float b_length, float fac = 2.0f, float min_rad = 0.0025f);
};

#endif // IMPROVEBYALLOMETRYLENGTH_H
