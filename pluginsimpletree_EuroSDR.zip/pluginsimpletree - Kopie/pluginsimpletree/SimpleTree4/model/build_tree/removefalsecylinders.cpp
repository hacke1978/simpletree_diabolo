#include "removefalsecylinders.h"


RemoveFalseCylinders::RemoveFalseCylinders(QSharedPointer<Tree> tree)
{
    _tree = tree;
    //qDebug() << "RemoveFalseCylinders " << "01";
    remove();
    //qDebug() << "RemoveFalseCylinders " << "02";
    merge();
    //qDebug() << "RemoveFalseCylinders " << "03";
}

void RemoveFalseCylinders::remove()
{
    QVector<QSharedPointer<Segment> > segments = _tree->get_leave_segments(_tree->get_root_segment());
    //qDebug() << "RemoveFalseCylinders" << "0a";
    QVectorIterator<QSharedPointer<Segment> > it (segments);
    while(it.hasNext())
    {
        QSharedPointer<Segment> segment = it.next();
        QVector<QSharedPointer<Cylinder> > cylinders = segment->get_cylinders();
     //   qDebug() << "RemoveFalseCylinders" << "0b";
        if(!(cylinders.size()>1))
        {
            segment->remove();
        }
    }
   // qDebug() << "RemoveFalseCylinders" << "0c";
}

void RemoveFalseCylinders::merge()
{
    bool do_merge = true;
    while(do_merge)
    {
        do_merge = false;
        QVector<QSharedPointer<Segment> > segments = _tree->get_all_segments();
        QVectorIterator<QSharedPointer<Segment> > it (segments);
        while(it.hasNext())
        {
            QSharedPointer<Segment> segment = it.next();
            if(segment->get_child_segments().size()==1)
            {
                do_merge = true;
                QSharedPointer<Segment> child = segment->get_child_segments().at(0);
                QVector<QSharedPointer<Segment> > grand_children = child->get_child_segments();
                child->remove();
                it.toBack();
                QVector<QSharedPointer<Cylinder> > cylinders = child->get_cylinders();
                QVectorIterator<QSharedPointer<Cylinder> > it2(cylinders);
                while(it2.hasNext())
                {
                    QSharedPointer<Cylinder> cylinder = it2.next();
                    segment->add_cylinder(cylinder);
                }
                QVectorIterator<QSharedPointer<Segment> > it3(grand_children);
                while(it3.hasNext())
                {
                    QSharedPointer<Segment> grand_child = it3.next();
                    segment->add_child_segment(grand_child);
                }
            }
        }
    }
}
