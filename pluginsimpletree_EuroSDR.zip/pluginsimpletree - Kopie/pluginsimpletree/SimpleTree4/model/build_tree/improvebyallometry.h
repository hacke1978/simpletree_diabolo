#ifndef IMPROVEBYALLOMETRY_H
#define IMPROVEBYALLOMETRY_H

#include "SimpleTree4/math/simplemath.h"
#include "SimpleTree4/model/tree.h"


class ImproveByAllometry
{
    float _min_rad = 0.0025f;
    float _fac = 2.0f;

    QSharedPointer<Tree> _tree;

    float _a;
    float _b;

    bool _inverse;

    void
    improve();

    float get_y_from_x(float x);
    float get_x_from_y(float y);
    MethodCoefficients _cf;

//    float
//    get_lower_x_from_y(float y);

//    float
//    get_upper_x_from_y(float y);

//    void
//    get_model_data(QVector<float> & x, QVector<float> & y,QVector<float> & x_model, QVector<float> & y_model,float max_y, float max_x);
public:
    ImproveByAllometry(QSharedPointer<Tree> tree, MethodCoefficients cf, float a, float b, float fac = 2.0, bool inverse = false);
};

#endif // IMPROVEBYALLOMETRY_H
