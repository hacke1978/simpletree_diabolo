#ifndef IMPROVEBYPIPEMODEL_H
#define IMPROVEBYPIPEMODEL_H

#include "SimpleTree4/model/tree.h"

class ImproveByPipeModel
{
    QSharedPointer<Tree> _tree;

    void
    improve();

public:
    ImproveByPipeModel(QSharedPointer<Tree> tree);
};

#endif // IMPROVEBYPIPEMODEL_H
