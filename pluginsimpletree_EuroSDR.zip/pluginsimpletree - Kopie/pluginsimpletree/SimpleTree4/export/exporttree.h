#ifndef EXPORTTREE_H
#define EXPORTTREE_H

#include <QSharedPointer>
#include <SimpleTree4/model/tree.h>
#include <SimpleTree4/method/method_coefficients.h>
#include <QTextStream>
#include <QFile>


class ExportTree
{
public:
    /**
     * @brief ExportTree Exports tree parameters to an export file
     * @param tree the Tree to be exported
     * @param coeff the method coefficients
     * @param path the path to the output file
     * @param extend_str set true if output file should be given another name
     */
    ExportTree(QSharedPointer<Tree> tree, MethodCoefficients coeff, QString path, bool extend_str = false);
};

#endif // EXPORTTREE_H
