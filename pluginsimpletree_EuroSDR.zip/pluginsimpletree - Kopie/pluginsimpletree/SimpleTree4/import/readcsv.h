#ifndef READCSV_H
#define READCSV_H

#include <QString>
#include <QMap>
#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QDebug>
#include <QMessageBox>


struct FileCoefficients{

    /**
     * @brief file QString for the output name
     */
    QString file = "";

    /**
     * @brief output_path The output path, pointing to Desktop standard
     */
    QString output_path = ""; //QStandardPaths::DesktopLocation;

    /**
     * @brief species A QString containing the species name
     */
    QString species = "unknown_species";

    /**
     * @brief volume a float to contain the volume
     */
    float volume = 0;

    /**
     * @brief use_allom a QString for allometry usage
     */
    QString use_allom = "true";


    float cut_height = 0.2f;
};

class ReadCSV
{
    /**
     * @brief map A Map between the FileCoefficients and the name
     */
    QMap<QString, FileCoefficients> map;
public:
    /**
     * @brief ReadCSV Standard constructor
     * @param path the path to where the csv should be written
     */
    ReadCSV(QString path);

    /**
     * @brief get_map The Getter for the map
     * @return
     */
    QMap<QString, FileCoefficients> get_map() const;
};

#endif // READCSV_H
