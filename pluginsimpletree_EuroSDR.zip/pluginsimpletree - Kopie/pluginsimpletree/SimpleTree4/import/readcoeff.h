#ifndef READCSV_H
#define READCSV_H

#include <QString>
#include <QMap>
#include <QFile>
#include <QTextStream>
#include <QStandardPaths>
#include <QDebug>
#include <QMessageBox>

#include "SimpleTree4/method/method_coefficients.h"



class ReadCoeff
{
private:

    QVector<MethodCoefficients> _coeff;

public:
    /**
     * @brief ReadCSV Standard constructor
     * @param path the path to where the csv should be written
     */
    ReadCoeff(QString path);

    /**
     * @brief get_map The Getter for the map
     * @return
     */
    QVector<MethodCoefficients> get_coeff() const;
};

#endif // READCSV_H
