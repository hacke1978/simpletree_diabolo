#ifndef READTREE_H
#define READTREE_H

#include <QString>
#include <QVector>
#include <SimpleTree4/model/cylinder.h>
#include <QSharedPointer>
#include <QFile>
#include <QMessageBox>

class ReadTree
{
    /**
     * @brief _cylinders A List of pointers to the cylinders
     */
    QVector<QSharedPointer<Cylinder> > _cylinders;
public:
    /**
     * @brief ReadTree standard constructor
     * @param path The path to the input file
     */
    ReadTree(QString path);

    /**
     * @brief get_cylinders The getter for the cylinder list
     * @return the cylinder list
     */
    QVector<QSharedPointer<Cylinder> > get_cylinders() const;
};

#endif // READTREE_H
