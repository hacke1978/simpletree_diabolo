#include "readcsv.h"

QMap<QString, FileCoefficients> ReadCSV::get_map() const
{
    return map;
}

ReadCSV::ReadCSV(QString path)
{
    QLocale::setDefault(QLocale(QLocale::English, QLocale::UnitedStates));
    map.clear();
    QFile file(path);
    if(!file.open(QIODevice::ReadOnly)) {
        QMessageBox::information(0, "error in ReadCSV", file.errorString());
    }
    QTextStream in (&file);
    while(!in.atEnd())
    {
        QString line = in.readLine();
        QStringList fields = line.split(",");
        QString file = fields.at(0);
        QString output_path = fields.at(1);
        QString species = fields.at(2);
        QString volume_string = fields.at(3);
        QString use_allom = fields.at(4);
        float volume = volume_string.toFloat();
        QString cut_height_string = fields.at(5);
        float cut_height = cut_height_string.toFloat();
        FileCoefficients coeff;
        coeff.file = file;
        coeff.output_path = output_path;
        coeff.species = species;
        coeff.volume = volume;
        coeff.use_allom = use_allom;
        coeff.cut_height = cut_height;
        map.insert(file,coeff);
    }
    file.close();
}
