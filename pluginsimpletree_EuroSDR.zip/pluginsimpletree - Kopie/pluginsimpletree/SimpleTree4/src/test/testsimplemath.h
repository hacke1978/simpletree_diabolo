#ifndef TESTSIMPLEMATH_H
#define TESTSIMPLEMATH_H

#include "src/math/simplemath.h"
#include <assert.h>
#include "src/model/cylinder.h"
#include <QSharedPointer>
#include <QWeakPointer>
#include <QtGlobal>

class TestSimpleMath
{
    float _max = 0.001;
public:
    TestSimpleMath();

    void
    test_median();

    void
    test_mean();

};

#endif // TESTSIMPLEMATH_H
