#ifndef ST_ACTIONSTEMPOINTDETECTION_H
#define ST_ACTIONSTEMPOINTDETECTION_H


#include "views/actions/st_actionstempointdetectionoptions.h"
#include "ct_actions/abstract/ct_abstractactionforgraphicsview.h"
#include "ct_itemdrawable/ct_scene.h"

#include <QRect>

class ST_ActionStemPointDetection_dataContainer
{
public:
    ST_ActionStemPointDetection_dataContainer();
    double            _eigen1_min;
    double            _eigen1_max;
    double            _eigen2_min;
    double            _eigen2_max;
    double            _eigen3_min;
    double            _eigen3_max;
};

class ST_ActionStemPointDetection : public CT_AbstractActionForGraphicsView
{
    Q_OBJECT
public:

    ST_ActionStemPointDetection(QList<CT_Scene*>* sceneList,  ST_ActionStemPointDetection_dataContainer* dataContainer);

    ~ST_ActionStemPointDetection();

    QString uniqueName() const;
    QString title() const;
    QString description() const;
    QIcon icon() const;
    QString type() const;

    void init();

    bool mousePressEvent(QMouseEvent *e);
    bool mouseMoveEvent(QMouseEvent *e);
    bool mouseReleaseEvent(QMouseEvent *e);
    bool wheelEvent(QWheelEvent *e);

    bool keyPressEvent(QKeyEvent *e);
    bool keyReleaseEvent(QKeyEvent *e);

    void draw(GraphicsViewInterface &view, PainterInterface &painter);
    void drawOverlay(GraphicsViewInterface &view, QPainter &painter);

    CT_AbstractAction* copy() const;

public slots:

    void update();

private slots:
    void redrawOverlay();
    void redrawOverlayAnd3D();


private:
    int         _value;
    QList<CT_Scene*>* _sceneList;



    ST_ActionStemPointDetection_dataContainer* _dataContainer;

};


#endif // ST_ACTIONSTEMPOINTDETECTION_H
