#include "st_stepfilterclustersbydistance.h"

// Alias for indexing models
#define DEFin_res "res"
#define DEFin_grp "grp"
#define DEFin_cloud_in "cloud_in"

//#define DEF_resultIn_inputResult "inputResult"
//#define DEF_groupIn_inputScene "inputGroup"
//#define DEF_itemIn_scene "inputScene"


#define DEFin_normals_in "no_in"
#define DEFin_stem_in "stem_in"
#define DEF_grp_out "grp_out"
#define DEF_cloud_out "grp_out"
#define DEFin_cluster_in "cluster_in"
#define DEFin_grp_in "grp_cluster_in"


//// Alias for indexing out models
#define DEF_resultOut_translated "extractedResult"
#define DEF_groupOut_pointCloud "extractedGroup"
#define DEF_itemOut_scene "extractedScene"



// Constructor : initialization of parameters
ST_StepFilterClustersByDistance::ST_StepFilterClustersByDistance(CT_StepInitializeData &dataInit) : CT_AbstractStep(dataInit)
{
    _centerX = 0;
    _centerY = 0;
    _centerZ = 0;
    _distance = 20;
}

ST_StepFilterClustersByDistance::~ST_StepFilterClustersByDistance()
{

}

// Step description (tooltip of contextual menu)
QString ST_StepFilterClustersByDistance::getStepDescription() const
{
    return tr("Filters clusters by the distance of the bounding box to a given point.");
}

// Step detailled description
QString ST_StepFilterClustersByDistance::getStepDetailledDescription() const
{
    return tr("Filters clusters by the distance of the bounding box to a given point." );
}

// Step URL
QString ST_StepFilterClustersByDistance::getStepURL() const
{
    return tr("http://www.simpletree.uni-freiburg.de/");
}

// Step copy method
CT_VirtualAbstractStep* ST_StepFilterClustersByDistance::createNewInstance(CT_StepInitializeData &dataInit)
{
    return new ST_StepFilterClustersByDistance(dataInit);
}

//////////////////// PROTECTED METHODS //////////////////

// Creation and affiliation of IN models
void ST_StepFilterClustersByDistance::createInResultModelListProtected()
{
    CT_InResultModelGroupToCopy * resultModel = createNewInResultModelForCopy(DEFin_res, tr("Clusters"));
    resultModel->setZeroOrMoreRootGroup();
    resultModel->addGroupModel("", DEFin_grp, CT_AbstractItemGroup::staticGetType(), tr("Grp_In"));
    resultModel->addItemModel(DEFin_grp, DEFin_cluster_in, CT_AbstractItemDrawableWithPointCloud::staticGetType(), tr("Clusters"));

}

// Creation and affiliation of OUT models
void ST_StepFilterClustersByDistance::createOutResultModelListProtected()
{
    createNewOutResultModelToCopy(DEFin_res);

}

// Semi-automatic creation of step parameters DialogBox
void ST_StepFilterClustersByDistance::createPostConfigurationDialog()
{
    CT_StepConfigurableDialog *configDialog = newStandardPostConfigurationDialog();
    configDialog->addText("Filters segmented clouds. The user has to give a distance which the clouds boundingbox has to be within in respect to a center point.");
    configDialog->addEmpty();
    configDialog->addDouble( tr("center point x "), " m",  0, 200,1,  _centerX, 1, "");
    configDialog->addDouble( tr("center point y "), " m",  0, 200,1,  _centerY, 1, "");
    configDialog->addDouble( tr("distance "), " m",  0,  99999999999,1,  _distance, 1, "");
      dialog_simple_tree(configDialog);
}

void ST_StepFilterClustersByDistance::compute()
{
        QList<CT_AbstractItemGroup*> groupsToBeRemoved;
    CT_ResultGroup *outRes = getOutResultList().first();

    size_t totalNumberOfClusters = 0;


    CT_ResultGroupIterator it(outRes, this, DEFin_grp);
    while (it.hasNext() && (!isStopped()))
    {
        CT_AbstractItemGroup *group = (CT_AbstractItemGroup*) it.next();
        const CT_AbstractItemDrawableWithPointCloud *item = (const CT_AbstractItemDrawableWithPointCloud*)group->firstItemByINModelName(this, DEFin_cluster_in);

        const CT_AbstractPointCloudIndex *pointCloudIndex = item->getPointCloudIndex();
        CT_PointIterator itP(pointCloudIndex);
                double x = 0;
                double y = 0;
                int counter = 0;
        while(itP.hasNext() )
        {
            const CT_Point &point = itP.next().currentPoint();
            x+= point[0];
            y+= point[1];
            counter++;
        }
        x/= counter;
        y/= counter;


        if(item != NULL)
        {
            ++totalNumberOfClusters;
            double dist = std::sqrt((x-_centerX)*(x-_centerX)+(y-_centerY)*(y-_centerY));

            if(!(dist<_distance))

                groupsToBeRemoved.append(group);
        }
    }

    size_t numberOfRemovedClusters = groupsToBeRemoved.size();
    while (!groupsToBeRemoved.isEmpty())
    {
        CT_AbstractItemGroup *group = groupsToBeRemoved.takeLast();
        recursiveRemoveGroupIfEmpty(group->parentGroup(), group);
    }

    PS_LOG->addMessage(LogInterface::info, LogInterface::step, QString(tr("Number of clouds before filtering : %1")).arg(totalNumberOfClusters));
    PS_LOG->addMessage(LogInterface::info, LogInterface::step, QString(tr("Number of clouds rejected : %1")).arg(numberOfRemovedClusters));

    setProgress( 100 );
    while (!groupsToBeRemoved.isEmpty())
    {
        CT_AbstractItemGroup *group = groupsToBeRemoved.takeLast();
        recursiveRemoveGroupIfEmpty(group->parentGroup(), group);
    }
}










void ST_StepFilterClustersByDistance::recursiveRemoveGroupIfEmpty(CT_AbstractItemGroup *parent, CT_AbstractItemGroup *group) const
{
    if(parent != NULL)
    {
        parent->removeGroup(group);

        if(parent->isEmpty())
            recursiveRemoveGroupIfEmpty(parent->parentGroup(), parent);
    }
    else
    {
        ((CT_ResultGroup*)group->result())->removeGroupSomethingInStructure(group);
    }
}




