#ifndef PREDICTSTARTPARAMETERS_H
#define PREDICTSTARTPARAMETERS_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/method/method_coefficients.h"
#include "SimpleTree4/method/point_cloud_operations/computemeanandstandarddeviation.h"
#include "SimpleTree4/import/readcsv.h"
#include "SimpleTree4/method/point_cloud_operations/predictstablevolume.h"


class PredictStartParameters
{
    PointCloudS::Ptr _cloud;

    MethodCoefficients _coeff;

    FileCoefficients _file_coeff;

private:
    int get_percentage();

    float get_height();

public:
    PredictStartParameters(PointCloudS::Ptr cloud, FileCoefficients file_coeff);

    MethodCoefficients get_coeff() const;
};

#endif // PREDICTSTARTPARAMETERS_H
