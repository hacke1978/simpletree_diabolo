#ifndef MODELLINGTHREADPOOL_H
#define MODELLINGTHREADPOOL_H

#include <QThreadPool>
#include <QEnableSharedFromThis>
#include <step/modelling/workermodelling.h>
#include <step/modelling/structstepprameter.h>

class ModellingThreadPool:  public QThreadPool, public QEnableSharedFromThis<ModellingThreadPool>
{
    Q_OBJECT
    QVector<StepParameter> _params;
public:
    ModellingThreadPool(QVector<StepParameter> params);

    void start_computation();

public slots:

    void sent_qstring_tp(QString str);

    void sent_finished_tp();

signals:


    void emit_finished_tp();

    void emit_qstring_tp(QString str);
};

#endif // MODELLINGTHREADPOOL_H
