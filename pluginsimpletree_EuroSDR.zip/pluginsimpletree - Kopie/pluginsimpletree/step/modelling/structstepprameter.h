#ifndef STRUCTSTEPPRAMETER_H
#define STRUCTSTEPPRAMETER_H

#include <QMap>
#include <SimpleTree4/import/readcsv.h>
#include "ct_step/abstract/ct_abstractstep.h"
#include "ct_result/ct_resultgroup.h"
#include "ct_itemdrawable/ct_fileheader.h"
#include "ct_itemdrawable/ct_standarditemgroup.h"
#include <SimpleTree4/method/method_coefficients.h>
#include "ct_itemdrawable/abstract/ct_abstractitemdrawablewithpointcloud.h"
#include <ct_step/abstract/ct_abstractstep.h>

struct StepParameter{
    CT_StandardItemGroup* itmgrp;
    CT_ResultGroup* resCpy_res;
    CT_FileHeader* itemCpy_header;
    QMap<QString, FileCoefficients> map;
    MethodCoefficients coeff;
    CT_AbstractItemDrawableWithPointCloud* itemCpy_cloud_in;

   // CT_AbstractStep * step;
    QString    _cloud_out_normals;
    QString    _cloud_out_stem;

    QString     _outCylinderGroupModelName;
    QString     _outCylinderModelName_unimproved;
    QString     _outCylinderModelName_improved_branch_junctions;
    QString     _outCylinderModelName_removed_false_cylinders;
    QString     _outCylinderModelName_removed_improved_by_median;
    QString     _outCylinderModelName_improved_by_fit;
    QString     _outCylinderModelName_improved_by_allometry;
    QString     _outCylinderModelName_improved_by_merge;



    QString     _model;
    QString     _coeff;


    QString _branchIDModelName;
    QString _branchOrderModelName;
    QString _segmentIDModelName;
    QString _parentSegmentIDModelName;
    QString _growthVolumeModelName;
    QString _tree_species;
    QString _tree_id;
    QString _detection_type;
    QString _improvement_type;


    QString     _topologyGroup;
    QString     _stemGroup;
    QString     _stemCylinders;
    bool use_dhs = true;
};



#endif // STRUCTSTEPPRAMETER_H
