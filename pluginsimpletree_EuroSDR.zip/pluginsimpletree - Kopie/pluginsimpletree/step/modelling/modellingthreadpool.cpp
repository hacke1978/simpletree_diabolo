#include "modellingthreadpool.h"

ModellingThreadPool::ModellingThreadPool(QVector<StepParameter> params): _params(params)
{
    int thread_number = QThread::idealThreadCount()-1;
    this->setMaxThreadCount(thread_number);


}

void ModellingThreadPool::start_computation()
{
    QVectorIterator<StepParameter> it (_params);
    while(it.hasNext())
    {
        StepParameter param = it.next();
        WorkerModelling * worker (new WorkerModelling(param, sharedFromThis()));
//        QObject::connect(worker, SIGNAL(emit_finished_worker())      , this, SLOT(sent_finished_tp()) );
//        QObject::connect(worker, SIGNAL(emit_qstring_worker(QString)), this, SLOT(sent_qstring_tp(QString)) );

        start(worker);
    }
    waitForDone();
}

void ModellingThreadPool::sent_qstring_tp(QString str)
{
   // qDebug() << "ThreadPool qstring reached";
    emit emit_qstring_tp(str);
}

void ModellingThreadPool::sent_finished_tp()
{
    emit emit_finished_tp();
}
