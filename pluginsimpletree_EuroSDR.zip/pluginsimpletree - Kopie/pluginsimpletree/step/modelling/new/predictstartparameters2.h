#ifndef PREDICTSTARTPARAMETERS2_H
#define PREDICTSTARTPARAMETERS2_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/method/method_coefficients.h"
#include "SimpleTree4/method/point_cloud_operations/computemeanandstandarddeviation.h"
#include "SimpleTree4/import/readcsv.h"
#include "SimpleTree4/method/point_cloud_operations/predictstablevolume.h"


class PredictStartParameters2
{
    PointCloudS::Ptr _cloud;

    MethodCoefficients _coeff;

//    FileCoefficients _file_coeff;

private:
    int get_percentage();

    float get_height();

    float _cut_height;

public:
    PredictStartParameters2(PointCloudS::Ptr cloud, float cut_height);

    MethodCoefficients get_coeff() const;
};

#endif // PREDICTSTARTPARAMETERS2_H
