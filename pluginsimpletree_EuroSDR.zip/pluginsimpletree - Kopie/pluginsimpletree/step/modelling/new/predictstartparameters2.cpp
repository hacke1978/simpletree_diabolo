#include "predictstartparameters2.h"

MethodCoefficients PredictStartParameters2::get_coeff() const
{
    return _coeff;
}

int PredictStartParameters2::get_percentage()
{
    int total = _cloud->points.size();
    int stm_pts = 0;
    for(size_t i = 0; i < total; i++)
    {
        if(_cloud->points.at(i).is_stem)
        {
            stm_pts ++;
        }
    }
    if(total==0)
    {
        return 0;
    }
    int percentage = (((float)stm_pts)/((float)total))*100.0f;
    return percentage;

}

float PredictStartParameters2::get_height()
{
    float z_min = std::numeric_limits<float>::max();
    float z_max = std::numeric_limits<float>::lowest();
    for(size_t j = 0; j < _cloud->points.size(); j++)
    {
        PointS p = _cloud->points.at(j);
        if(p.z < z_min)
        {
            z_min = p.z;
        }

        if(p.z > z_max)
        {
            z_max = p.z;
        }
    }
    float height = z_max - z_min + _cut_height;
    return height;
}

PredictStartParameters2::PredictStartParameters2(PointCloudS::Ptr cloud, float cut_height): _cloud(cloud), _cut_height(cut_height)
{

    ComputeMeanAndStandardDeviation m_sd(_cloud);
//    _coeff.id = _file_coeff.file;
//    _coeff.species = _file_coeff.species;
    _coeff.species = "unknown";
    _coeff.cut_height = _cut_height;
    _coeff.sd = m_sd._sd;
    _coeff.mean = m_sd._mean;
    _coeff.epsilon_cluster_branch = 3*(m_sd._mean + 2*m_sd._sd);

    int percentage = get_percentage();

    if(percentage>5&&percentage<90)
    {
        _coeff.optimze_stem = true;
    }



    float height = get_height();

    if(height > 10)
    {
        _coeff.epsilon_sphere = 0.03;
//        _coeff.allometry_b = 3;
    } else
    {
        _coeff.optimze_stem = false;
//        _coeff.allometry_b = 2;
    }

    PredictStableVolume pv (_cloud, _coeff);
    _coeff = pv.get_coeff();
}
