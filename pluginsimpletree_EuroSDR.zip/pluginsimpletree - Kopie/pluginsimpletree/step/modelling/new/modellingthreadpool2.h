#ifndef MODELLINGTHREADPOOL2_H
#define MODELLINGTHREADPOOL2_H

#include <QThreadPool>
#include <QStringList>
#include <QEnableSharedFromThis>
#include <step/modelling/new/workermodelling2.h>
#include <step/modelling/new/structstepprameter2.h>

class ModellingThreadPool2:  public QThreadPool, public QEnableSharedFromThis<ModellingThreadPool2>
{
    Q_OBJECT
    QVector<StepParameter2> _params;

    int _number_cylinders_total = 0;
public:
    ModellingThreadPool2(QVector<StepParameter2> params);

    void start_computation();

    QStringList timings;

public slots:

    void count_cylinders(int number_per_tree);

    void sent_timings(QString str);

    void sent_qstring_tp(QString str);

    void sent_finished_tp();

signals:


    void emit_finished_tp();

    void emit_qstring_tp(QString str);

    void emit_timinglist(QStringList timings);

    void emit_number_cylinders(int total_number_cylinders);
};

#endif // MODELLINGTHREADPOOL2_H
