#include "modellingthreadpool2.h"

ModellingThreadPool2::ModellingThreadPool2(QVector<StepParameter2> params): _params(params)
{
    int thread_number = QThread::idealThreadCount()-1;
    thread_number = std::max(11,thread_number);
    //    int thread_number = 1;
    QThreadPool::globalInstance()->setMaxThreadCount(thread_number);
    this->setMaxThreadCount(thread_number);
    QString str("convert;parameter_find;single_model;iterative_model;attractor;build_tree;pype;improve;rest;nmbrpts;id \n");
    timings.push_back(str);


}

void ModellingThreadPool2::start_computation()
{
    QVectorIterator<StepParameter2> it (_params);
    while(it.hasNext())
    {
        StepParameter2 param = it.next();
        WorkerModelling2 * worker (new WorkerModelling2(param, sharedFromThis()));
        start(worker);
    }
    waitForDone();
    emit_timinglist(timings);
    emit_number_cylinders(_number_cylinders_total);
}

void ModellingThreadPool2::count_cylinders(int number_per_tree)
{
    _number_cylinders_total += number_per_tree;
}

void ModellingThreadPool2::sent_timings(QString str)
{
    timings.push_back(str);
}

void ModellingThreadPool2::sent_qstring_tp(QString str)
{
    emit emit_qstring_tp(str);
}

void ModellingThreadPool2::sent_finished_tp()
{
    emit emit_finished_tp();
}
