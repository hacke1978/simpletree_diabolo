#include "st_modellingthreadpool.h"

ST_ModellingThreadPool::ST_ModellingThreadPool(QVector<ST_StepParameter> params): _params(params)
{
    int thread_number = QThread::idealThreadCount()-1;
    this->setMaxThreadCount(thread_number);


}

void ST_ModellingThreadPool::start_computation()
{
    QVectorIterator<ST_StepParameter> it (_params);
    while(it.hasNext())
    {
        ST_StepParameter param = it.next();
        ST_Workemodelling * worker (new ST_Workemodelling(param, sharedFromThis()));
        QObject::connect(worker, SIGNAL(emit_finished_worker())      , this, SLOT(sent_finished_tp()) );
        QObject::connect(worker, SIGNAL(emit_qstring_worker(QString)), this, SLOT(sent_qstring_tp(QString)) );
        start(worker);
    }
    waitForDone();
}

void ST_ModellingThreadPool::sent_qstring_tp(QString str)
{
    emit emit_qstring_tp(str);
}

void ST_ModellingThreadPool::sent_finished_tp()
{
    emit emit_finished_tp();
}
