#ifndef ST_MODELLINGTHREADPOOL_H
#define ST_MODELLINGTHREADPOOL_H

#include <QThreadPool>
#include <QEnableSharedFromThis>
#include "step/modelling/split/st_workermodelling.h"
#include "step/modelling/split/st_stepparameter.h"

class ST_ModellingThreadPool:  public QThreadPool, public QEnableSharedFromThis<ST_ModellingThreadPool>
{
    Q_OBJECT
    QVector<ST_StepParameter> _params;
public:
    ST_ModellingThreadPool(QVector<ST_StepParameter> params);

    void start_computation();

public slots:

    void sent_qstring_tp(QString str);

    void sent_finished_tp();

signals:


    void emit_finished_tp();

    void emit_qstring_tp(QString str);
};

#endif // ST_MODELLINGTHREADPOOL_H
