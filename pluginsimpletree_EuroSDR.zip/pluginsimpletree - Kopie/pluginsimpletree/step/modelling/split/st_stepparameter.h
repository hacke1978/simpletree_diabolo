#ifndef ST_STEPPARAMETER_H
#define ST_STEPPARAMETER_H

#include <QMap>
#include <SimpleTree4/import/readcsv.h>
#include "ct_step/abstract/ct_abstractstep.h"
#include "ct_result/ct_resultgroup.h"
#include "ct_itemdrawable/ct_fileheader.h"
#include "ct_itemdrawable/ct_standarditemgroup.h"
#include <SimpleTree4/method/method_coefficients.h>
#include "item/st_coefficients.h"
#include "item/st_tree.h"
#include "ct_itemdrawable/abstract/ct_abstractitemdrawablewithpointcloud.h"
#include <ct_step/abstract/ct_abstractstep.h>

struct ST_StepParameter{
    CT_StandardItemGroup* grpCpy_grp;
    CT_ResultGroup* resCpy_res;
    CT_FileHeader* itemCpy_header;

    ST_Coefficients* coeff_in;
    ST_Tree * tree_in;

    CT_AbstractItemDrawableWithPointCloud* itemCpy_cloud_in;



    QString     _cylinder_grp;
    QString     _cylinders;

    QString     _model;
    QString     _coeff;
    QString     _tree_out;


    QString _branchIDModelName;
    QString _branchOrderModelName;
    QString _segmentIDModelName;
    QString _parentSegmentIDModelName;
    QString _growthVolumeModelName;
    QString _tree_species;
    QString _tree_id;
    QString _detection_type;
    QString _improvement_type;


    QString     _topologyGroup;
    QString     _stemGroup;
    QString     _stemCylinders;

};



#endif // ST_STEPPARAMETER_H
