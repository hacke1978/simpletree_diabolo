#ifndef BUILDTOPOLOGY_H
#define BUILDTOPOLOGY_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "dijkstra_coefficients.h"
#include <QVector>
#include <QDebug>
#include "SimpleTree4/method/point_cloud_operations/bincloud.h"
#include "SimpleTree4/math/simplemath.h"


class BuildTopology
{
    DijkstraCoefficients _coeff;

    PointCloudS::Ptr _cloud_in;

    QVector<pcl::ModelCoefficients> _skeleton_coeff;

    void initialize();

    QVector<PointCloudS::Ptr> _bin_clusters;

    void compute();

public:

    BuildTopology(PointCloudS::Ptr cloud_in, DijkstraCoefficients coeff);

    QVector<pcl::ModelCoefficients> get_skeleton_coeff() const;
};

#endif // BUILDTOPOLOGY_H
