#ifndef GENERATESKELETONCLOUD_H
#define GENERATESKELETONCLOUD_H

#include "SimpleTree4/model/pointsimpletree.h"
#include "SimpleTree4/method/point_cloud_operations/bincloud.h"
#include "SimpleTree4/method/point_cloud_operations/clustercloud.h"
#include "dijkstra_coefficients.h"
#include <pcl/common/centroid.h>
#include <QDebug>

class GenerateSkeletonCloud
{
    float _bin_width;

    PointCloudS::Ptr _cloud_in;

    PointCloudS::Ptr _cloud_out;

    PointCloudS::Ptr _skeleton;

    QVector<PointCloudS::Ptr> _bin_clusters;

    QVector<QVector<PointCloudS::Ptr> > _clusters;

    DijkstraCoefficients _coeff;

public:
    void compute();

    GenerateSkeletonCloud(PointCloudS::Ptr cloud_in,  DijkstraCoefficients coeff);

    PointCloudS::Ptr get_cloud_out() const;

    PointCloudS::Ptr get_skeleton() const;
};

#endif // GENERATESKELETONCLOUD_H
