#ifndef CLUSTERANDSORT_H
#define CLUSTERANDSORT_H

#include "SimpleTree4/model/pointsimpletree.h"
#include <QVector>
#include <QPair>
#include <QDebug>
#include <pcl/kdtree/kdtree.h>
#include "dijkstra_coefficients.h"

class ClusterAndSort
{
    DijkstraCoefficients _coeff;

    QVector<QPair<pcl::search::KdTree<PointS>::Ptr, PointCloudS::Ptr> > _pairs;

    PointCloudS::Ptr _cloud_in;

    PointCloudS::Ptr _cloud_processed;

    PointCloudS::Ptr _cloud_unprocessed;

    PointS _next_point;

    QVector<PointCloudS::Ptr> _cluster_large;

    pcl::search::KdTree<PointS>::Ptr _tree;

    int _total_size;

    void subdivide_clouds();

    void next_pt();

//    void cluster_cloud();

//    void sort();

public:
    ClusterAndSort(PointCloudS::Ptr cloud_in, DijkstraCoefficients coeff);

    PointS get_next_point() const;
};

#endif // CLUSTERANDSORT_H
