#include "generateskeletoncloud.h"

PointCloudS::Ptr GenerateSkeletonCloud::get_cloud_out() const
{
    return _cloud_out;
}

PointCloudS::Ptr GenerateSkeletonCloud::get_skeleton() const
{
    return _skeleton;
}

void GenerateSkeletonCloud::compute()
{
    BinCloud bc (_cloud_in, _coeff.bin_width);
    _bin_clusters = bc.get_clusters();

    QVectorIterator<PointCloudS::Ptr> it(_bin_clusters);
    while(it.hasNext())
    {
        PointCloudS::Ptr bin_cluster = it.next();
        QVector<PointCloudS::Ptr> sub_clusters = ClusterCloud::cluster(bin_cluster,_coeff.cluster_for_bin,1);
        _clusters.push_back(sub_clusters);
    }
    int cluster_ID = 0;
    _cloud_out.reset(new PointCloudS);
    _skeleton.reset(new PointCloudS);
    for(size_t i = 0; i < _clusters.size(); i++)
    {
        QVector<PointCloudS::Ptr> sub_clusters = _clusters[i];
        for(size_t j = 0; j < sub_clusters.size(); j++)
        {
            PointCloudS::Ptr cluster = sub_clusters[j];
            size_t size = cluster->points.size();
            for(size_t k = 0; k < size; k++)
            {
                cluster->points[k].cluster = cluster_ID;
                _cloud_out->push_back(cluster->points[k]);
            }
            Eigen::Matrix<float,4,1> centroid;
            pcl::compute3DCentroid(*cluster,centroid);
            PointS center;
            center.x = centroid.coeff(0);
            center.y = centroid.coeff(1);
            center.z = centroid.coeff(2);
            center.ID = cluster->points[0].ID;
            center.rangebin = cluster->points[0].rangebin;
            center.treeID = cluster->points[0].treeID;
            center.cluster = cluster->points[0].cluster;
            center.ID = cluster->points[0].ID;
            center.distance = cluster->points[0].distance;
            cluster_ID++;
            _skeleton->push_back(center);
        }
    }
}

GenerateSkeletonCloud::GenerateSkeletonCloud(PointCloudS::Ptr cloud_in, DijkstraCoefficients coeff):
    _cloud_in(cloud_in), _coeff(coeff)
{
    compute();
}
