#ifndef DIJKSTRA_COEFFICIENTS_H
#define DIJKSTRA_COEFFICIENTS_H

struct DijkstraCoefficients{

    const int TREE_CLUSTER_MIN_SIZE = 100;

    const float OCTREE_CELL_SIZE = 0.025f;

    float search_range = 0.05f;

    float max_distance = 0.05f;

    float down_scale_size = 0.01f;

    float cluster_for_bin = 0.03f;

    float bin_width = 0.06f;

    float percentage_for_large_cluster = 0.01;

    float punishment_additative = 0.02;

    float punishment_multiplicative = 5;

    float punishment_power = 1;

};




#endif // DIJKSTRA_COEFFICIENTS_H
