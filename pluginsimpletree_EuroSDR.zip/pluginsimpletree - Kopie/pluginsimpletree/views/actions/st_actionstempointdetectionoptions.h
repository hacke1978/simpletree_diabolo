#ifndef ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H
#define ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H

#include "ct_view/actions/abstract/ct_gabstractactionoptions.h"

class ST_ActionStemPointDetection;

namespace Ui {
class ST_ActionStemPointDetectionOptions;
}

class ST_ActionStemPointDetectionOptions : public CT_GAbstractActionOptions
{
    Q_OBJECT

public:

    explicit ST_ActionStemPointDetectionOptions(const ST_ActionStemPointDetection *action);
    ~ST_ActionStemPointDetectionOptions();

    double get_eigen_1_min() const;
    double get_eigen_1_max() const;

    double get_eigen_2_min() const;
    double get_eigen_2_max() const;

    double get_eigen_3_min() const;
    double get_eigen_3_max() const;

    void set_eigen_1_min(double x);
    void set_eigen_1_max(double x);
    void set_eigen_2_min(double x);
    void set_eigen_2_max(double x);
    void set_eigen_3_min(double x);
    void set_eigen_3_max(double x);


//    bool isExemple2Checked();

private:
    Ui::ST_ActionStemPointDetectionOptions *ui;

signals:
    void parametersChanged();

};

#endif // ST_ACTIONSTEMPOINTDETECTIONOPTIONS_H
